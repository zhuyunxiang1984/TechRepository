﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;


namespace OWG.RaidLevelEditor
{
    [ExecuteInEditMode]
    public class MapGridMono : MonoBehaviour
    {
        [LabelText("地块index"), DisplayAsString]
        public int id;

        [LabelText("地块等级")]
        public int mapLv;

        [LabelText("地块基础信息"), OnValueChanged("_LocateForce")]
        public int mapBasicInfoID;

        [CustomValueDrawer("_EditDrawGroundType")]
        public MapType groundType;
        MapType _EditDrawGroundType(MapType value)
        {
            value = (MapType)EditorGUILayout.Popup("地块类型", (int)value, RaidLevelUtil.GroundTypeNames.GetNameList().ToArray());
            return value;
        }

        [LabelText("不可行走"), OnValueChanged("_OnWalkableChanged")]
        public bool unWalkable;

        [BoxGroup("建筑")]
        [HorizontalGroup("建筑/1"), HideLabel, OnValueChanged("_OnBuildingChanged")]
        public int buildingID;
        [BoxGroup("建筑")]
        [HorizontalGroup("建筑/1"), Button("选择")]
        void EditOpenSelectBuildingPanel()
        {
            EditSelectPanel.Open(EnumConfigName.BuildingBasic, (value)=>
            {
                //Debug.Log("select " + value);
                buildingID = value;
                _OnBuildingChanged();
            });
        }

        [BoxGroup("单位")]
        [HorizontalGroup("单位/1"), HideLabel, OnValueChanged("_OnForceChanged")]
        public int forceID;
        [BoxGroup("单位")]
        [HorizontalGroup("单位/1"), Button("选择")]
        void EditOpenSelectForcePanel()
        {
            EditSelectPanel.Open(EnumConfigName.Force, (value) =>
            {
                //Debug.Log("select " + value);
                forceID = value;
                _OnForceChanged();
            });
        }

        [BoxGroup("奖励")]
        [HorizontalGroup("奖励/1"), HideLabel, OnValueChanged("_OnRewardChanged")]
        public int rewardID;
        [BoxGroup("奖励")]
        [HorizontalGroup("奖励/1"), Button("选择")]
        void EditOpenSelectRewardPanel()
        {
            EditSelectPanel.Open(EnumConfigName.Item, (value) =>
            {
                //Debug.Log("select " + value);
                rewardID = value;
                _OnRewardChanged();
            });
        }

        //void OnDrawGizmosSelected()
        //{
        //    Gizmos.color = new Color(0.36f, 0.94f, 0.23f, 0.5f);
        //    Gizmos.DrawCube(transform.position, new Vector3(RaidLevelConst.MapUnitWidth, 5, RaidLevelConst.MapUnitWidth));
        //}

        List<Texture> m_DrawIcons = new List<Texture>();
        private void OnDrawGizmos()
        {
            var icon = AssetDatabase.LoadAssetAtPath<Texture>(RaidLevelConst.EventIcon);
            m_DrawIcons.Clear();

            var point = HandleUtility.WorldToGUIPoint(transform.position + Vector3.up * 50f);

            GUI.color = Color.white;
            Handles.BeginGUI();
            _DrawWindow(point, $"Index:{id}", m_DrawIcons);
            Handles.EndGUI();
        }
        private void _DrawWindow(Vector2 screenPoint, string text, List<Texture> icons)
        {
            var size = RaidLevelConst.IconSize;
            var padding = RaidLevelConst.IconPadding;
            var fontSize = 7;

            var textWidth = text.Length * fontSize;
            var textHeight = size;
            var iconsWidth = icons.Count * size + (icons.Count - 1) * padding;
            var iconsHeight = icons.Count > 0 ? size : 0f;

            var totalW = Mathf.Max(textWidth, iconsWidth);
            var totalH = textHeight + iconsHeight;

            var windowRect = new Rect(screenPoint.x - totalW * 0.5f, screenPoint.y - totalH, totalW, totalH);
            GUI.Box(windowRect, string.Empty);

            var titleRect = new Rect(screenPoint.x - textWidth * 0.5f, windowRect.y, textWidth, textHeight);
            GUI.Label(titleRect, text);
            
            for (int i = 0; i < icons.Count; ++i)
            {
                var rect = new Rect(screenPoint.x - iconsWidth * 0.5f + i * (size + padding), titleRect.y + textHeight, size, size);
                GUI.DrawTexture(rect, icons[i]);
            }

        }

        public void SetData(int id, MapInfo mapInfo, MapBasicInfo mapBasicInfo, Transform decorateRoot)
        {
            this.id = id;

            groundType = (MapType)mapInfo.groundType;
            unWalkable = mapInfo.type == 0;

            mapLv = mapBasicInfo.mapLv;
            buildingID = mapBasicInfo.buildingID;
            forceID = mapBasicInfo.unitIndex;
            rewardID = mapBasicInfo.mapReward;
            mapBasicInfoID = mapBasicInfo.mapBasicInfoID;
            

            _CreateDecorate(mapInfo.elements, decorateRoot);
            _CreateBuilding(buildingID);
            _CreateForce(forceID);
            _LocateForce();
            _CreateReward(rewardID);
            _OnWalkableChanged();
        }

        public void GetData(ref MapInfo mapInfo, ref MapBasicInfo mapBasicInfo)
        {
            mapInfo.groundType = (int)groundType;
            mapInfo.type = unWalkable ? 0 : 1;

            mapBasicInfo.mapLv = mapLv;
            mapBasicInfo.buildingID = buildingID;
            mapBasicInfo.unitIndex = forceID;
            mapBasicInfo.mapReward = rewardID;
        }

        void _CreateDecorate(string content, Transform decorateRoot)
        {
            var array1 = content.Split('#');
            for (int i = 0; i < array1.Length; ++i)
            {
                var array2 = array1[i].Split('|');
                if (array2.Length < 3)
                    break;
                var resName = array2[0];
                var posStr = array2[1];
                var rotStr = array2[2];
                var posArr = posStr.Split('*');
                if (posArr.Length < 3)
                    break;
                var prefab = _LoadAsset(resName);
                if (prefab == null)
                {
                    Debug.LogError($"资源不存在 {resName}");
                    continue;
                }
                var go = Instantiate(prefab, decorateRoot);
                go.name = $"Grid{id}_{resName}";
                go.transform.localPosition = new Vector3(float.Parse(posArr[0]), float.Parse(posArr[1]), float.Parse(posArr[2]));
                go.transform.localRotation = Quaternion.Euler(0f, float.Parse(rotStr), 0f);
            }
        }

        GameObject _LoadAsset(string resName)
        {
            int assetCount = RaidLevelConst.MapDecoratePath.Length;
            for (int i = 0; i < assetCount; ++i)
            {
                var assetPath = $"{RaidLevelConst.MapDecoratePath[i]}/Decorate_{resName}.prefab";
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                if (prefab != null)
                    return prefab;
            }
            return null;
        }

#region 建筑相关

        protected static string m_BuildingObjName = "Building";
        protected GameObject m_BuildingObj;
        void _OnBuildingChanged()
        {
            _FindBuilding();
            _RemoveBuilding();
            _CreateBuilding(buildingID);
        }
        void _FindBuilding()
        {
            if (m_BuildingObj != null)
                return;
            foreach (Transform child in transform)
            {
                if (child.name.StartsWith(m_BuildingObjName))
                {
                    m_BuildingObj = child.gameObject;
                    return;
                }
            }
        }
        void _CreateBuilding(int buildingId)
        {
            var configManager = ConfigManager.instance;
            var buildingBasicInfo = configManager.GetItem<BuildingBasicInfo>(EnumConfigName.BuildingBasic, buildingId);
            if (buildingBasicInfo == null)
                return;
            int id = buildingId * 1000 + buildingBasicInfo.initLevel;
            var buildingLevelInfo = configManager.GetItem<BuildingLevelInfo>(EnumConfigName.BuildingLevel, id);
            if (buildingLevelInfo == null)
                return;
            var buildingInfo = configManager.GetItem<BuildingInfo>(EnumConfigName.Building, buildingLevelInfo.expand);
            if (buildingInfo == null)
                return;
            var assetPath = $"{RaidLevelConst.MapBuidingPath}/{buildingInfo.resource}.prefab";
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (prefab == null)
            {
                Debug.LogError($"资源不存在 {assetPath}");
                return;
            }
            m_BuildingObj = Instantiate(prefab, transform);
            m_BuildingObj.name = $"{m_BuildingObjName}_{buildingId}";
            m_BuildingObj.transform.localScale = Vector3.one * buildingInfo.zoomSzie;
            RaidLevelUtil.SetLayer(m_BuildingObj.transform, RaidLevelConst.IgnoreSeletLayer);
        }
        void _RemoveBuilding()
        {
            if (m_BuildingObj == null)
                return;
            DestroyImmediate(m_BuildingObj);
            m_BuildingObj = null;
        }

#endregion

#region 单位相关

        protected static string m_ForceObjName = "Force";
        protected List<GameObject> m_ForceObjs = new List<GameObject>();
        void _OnForceChanged()
        {
            _FindForce();
            _RemoveForce();
            _CreateForce(forceID);
            _LocateForce();
        }
        void _FindForce()
        {
            if (m_ForceObjs.Count > 0)
                return;
            foreach (Transform child in transform)
            {
                if (child.name.StartsWith(m_ForceObjName))
                {
                    m_ForceObjs.Add(child.gameObject);
                }
            }
        }
        void _CreateForce(int forceId)
        {
            var configManager = ConfigManager.instance;
            var forceInfo = configManager.GetItem<ForceInfo>(EnumConfigName.Force, forceId);
            if (forceInfo == null || string.IsNullOrEmpty(forceInfo.division))
                return;
            var divisionIds = forceInfo.division.Split('|');
            foreach (var divisionIdStr in divisionIds)
            {
                var divisionId = int.Parse(divisionIdStr);
                var divisionInfo = configManager.GetItem<DivisionInfo>(EnumConfigName.Division, divisionId);
                if (divisionInfo == null)
                    continue;
                int brigadeInt = int.Parse(divisionInfo.brigade);
                var unitLevelInfo = configManager.GetItem<UnitLevelInfo>(EnumConfigName.UnitLevel, brigadeInt);
                if (unitLevelInfo == null)
                    continue;
                var unitInfo = configManager.GetItem<UnitInfo>(EnumConfigName.Unit, unitLevelInfo.unitId);
                if (unitInfo == null)
                    continue;
                var assetPath = $"{RaidLevelConst.UnitAssetPath}/{unitInfo.resource}.prefab";
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                if (prefab == null)
                {
                    Debug.LogError($"没有资源 {assetPath}");
                    continue;
                }
                var go = Instantiate(prefab, transform);
                go.name = $"{m_ForceObjName}_{forceId}";
                go.transform.localPosition = Vector3.zero;
                go.transform.localRotation = Quaternion.identity;
                RaidLevelUtil.SetLayer(go.transform, RaidLevelConst.IgnoreSeletLayer);
                m_ForceObjs.Add(go);
            }
        }
        void _RemoveForce()
        {
            foreach(var go in m_ForceObjs)
            {
                DestroyImmediate(go);
            }
            m_ForceObjs.Clear();
        }

        void _LocateForce()
        {
            _FindForce();
            var mapUnitGridData = RaidLevelUtil.GetMapUnitGridList(mapBasicInfoID);
            if (mapUnitGridData == null)
                return;
            int count = m_ForceObjs.Count;
            for (int i = 0; i < count && i < mapUnitGridData.Count; ++i)
            {
                var go = m_ForceObjs[i];
                var pos = RaidLevelUtil.GetGridPos(mapUnitGridData[i], RaidLevelConst.MapUnitGridCount, RaidLevelConst.MapUnitWidth);
                pos.x -= RaidLevelConst.MapUnitWidth * 0.5f;
                pos.y -= RaidLevelConst.MapUnitWidth * 0.5f;
                go.transform.localPosition = new Vector3(pos.x, 0f, pos.y);
            }
        }

#endregion

#region 奖励相关

        protected static string m_RewardObjName = "Reward";
        protected GameObject m_RewardObj;
        void _OnRewardChanged()
        {
            _FindReward();
            _RemoveReward();
            _CreateReward(rewardID);
        }
        void _FindReward()
        {
            if (m_RewardObj != null)
                return;
            foreach (Transform child in transform)
            {
                if (child.name.StartsWith(m_RewardObjName))
                {
                    m_RewardObj = child.gameObject;
                    return;
                }
            }
        }
        void _CreateReward(int rewardId)
        {
            var configManager = ConfigManager.instance;
            var itemInfo = configManager.GetItem<ItemInfo>(EnumConfigName.Item, rewardId);
            if (itemInfo == null || string.IsNullOrEmpty(itemInfo.modelID))
                return;
            var assetPath = $"{RaidLevelConst.ItemAssetPath}/{itemInfo.modelID}.prefab";
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (prefab == null)
            {
                Debug.LogError($"资源不存在 {assetPath}");
                return;
            }
            m_RewardObj = Instantiate(prefab, transform);
            m_RewardObj.name = $"{m_RewardObjName}_{rewardId}";

            if (!string.IsNullOrEmpty(itemInfo.effects))
            {
                var effAssetPath = $"{RaidLevelConst.EffectAssetPath}/{itemInfo.effects}.prefab";
                var effPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(effAssetPath);
                if (effPrefab != null)
                {
                    Instantiate(effPrefab, m_RewardObj.transform);
                }
            }

            RaidLevelUtil.SetLayer(m_RewardObj.transform, RaidLevelConst.IgnoreSeletLayer);
        }
        void _RemoveReward()
        {
            if (m_RewardObj == null)
                return;
            DestroyImmediate(m_RewardObj);
            m_RewardObj = null;
        }

        #endregion

#region 可行走区域

        private string m_UnwalkableName = "unwalkable";
        private GameObject m_UnwalkableObj;
        void _OnWalkableChanged()
        {
            if (m_UnwalkableObj == null)
            {
                var trans = transform.Find(m_UnwalkableName);
                if (trans != null)
                {
                    m_UnwalkableObj = trans.gameObject;
                }
            }
            if (unWalkable)
            {
                if (m_UnwalkableObj == null)
                {
                    var assetPath = RaidLevelConst.UnwalkablePath;
                    var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                    m_UnwalkableObj = GameObject.Instantiate(prefab, transform);
                    m_UnwalkableObj.name = m_UnwalkableName;
                    RaidLevelUtil.SetLayer(m_UnwalkableObj.transform, RaidLevelConst.IgnoreSeletLayer);
                }
            }
            else
            {
                if (m_UnwalkableObj != null)
                {
                    GameObject.DestroyImmediate(m_UnwalkableObj);
                    m_UnwalkableObj = null;
                }
            }
        }

        #endregion

    }
}
#endif