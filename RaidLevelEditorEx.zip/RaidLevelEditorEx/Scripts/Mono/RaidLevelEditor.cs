﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    [ExecuteInEditMode]
    public class RaidLevelEditor : MonoBehaviour
    {
        #region 编辑

        [BoxGroup("配置表")]
        [LabelText("根目录")]
        public string configRoot = RaidLevelConst.RaidLevelEditorConfigRootDefault;

        [BoxGroup("配置表")]
        [Button("手动加载", ButtonSizes.Medium)]
        void EditLoadConfig()
        {
            EditorPrefs.SetString(RaidLevelConst.RaidLevelEditorConfigRootKey, configRoot);
            RaidLevelUtil.LoadConfigs(true, false);
        }

        [BoxGroup("加载副本")]
        [LabelText("副本Id")]
        public int RaidLevelId;

        [BoxGroup("加载副本")]
        [Button("加载", ButtonSizes.Medium)]
        void EditLoadRaidLevel()
        {
            _LoadRaidLevel(RaidLevelId);
        }

        #endregion

        [LabelText("显示unity辅助"), OnValueChanged("_EditUpdateUnityTool")]
        public bool showTool = false;

        void _EditUpdateUnityTool()
        {
            Tools.hidden = !showTool;
        }

        //
        [UnityEditor.Callbacks.DidReloadScripts(0)]
        static void OnScriptReload()
        {
            scriptReloaded = true;
        }
        static bool scriptReloaded = true;

        private void Awake()
        {
#if UNITY_EDITOR
            configRoot = RaidLevelUtil.GetConfigRoot();
#endif
        }
        private void OnEnable()
        {
            showTool = false;
            Tools.hidden = !showTool;
            Tools.lockedLayers |= 1 << RaidLevelConst.IgnoreSeletLayer;
        }
        private void OnDisable()
        {
            showTool = true;
            Tools.hidden = !showTool;
            Tools.lockedLayers ^= 1 << RaidLevelConst.IgnoreSeletLayer;
        }

        private void Update()
        {
            if (scriptReloaded)
            {
                _OnScriptReloaded();
                scriptReloaded = false;
            }
        }

        void _OnScriptReloaded()
        {
            RaidLevelUtil.LoadConfigs(false, true);
        }

        //加载副本
        void _LoadRaidLevel(int id)
        {
            var raidLevelRawData = ConfigManager.instance.GetItem<RaidLevelInfo>(EnumConfigName.RaidLevel, id);
            if (raidLevelRawData == null)
            {
                EditorUtility.DisplayDialog("", $"没有找到副本{id}!!", "OK");
                return;
            }
            var go = new GameObject($"RaidLevel_{id}");
            var raidLevelMono = go.AddComponent<RaidLevelMono>();
            raidLevelMono.SetData(raidLevelRawData);
        }
        
    }
}

#endif