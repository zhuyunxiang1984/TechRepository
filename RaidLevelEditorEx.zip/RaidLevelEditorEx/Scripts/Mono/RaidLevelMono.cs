﻿using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public class RaidLevelMono : MonoBehaviour
    {
        [ContextMenu("重新加载配置表")]
        void _EditReloadConfigs()
        {
            RaidLevelUtil.LoadConfigs(true, false);
        }

        [LabelText("副本ID"), DisplayAsString]
        public int id;

        [LabelText("副本SizeW"), DisplayAsString]
        public int sizeW;
        [LabelText("副本SizeH"), DisplayAsString]
        public int sizeH;

        [LabelText("Map"), DisplayAsString]
        public string map;

        [LabelText("MapBasic"), DisplayAsString]
        public string mapBasic;

        [LabelText("MapInitRes"), DisplayAsString]
        public string mapInitRes;

        [LabelText("mapEvent"), DisplayAsString]
        public string mapEvent;

        [LabelText("副本名字"), OnValueChanged("_UpdateLevelName")]
        public int levelName;
        [LabelText("副本名字"), DisplayAsString]
        public string levelNameCnStr;

        [LabelText("副本关卡号"), OnValueChanged("_UpdateLevelNum")]
        public int levelNum;
        [LabelText("副本关卡号"), DisplayAsString]
        public string levelNumCnStr;

        [LabelText("关卡起始镜头")]
        public int cameraStartPos;

        [Serializable]
        public struct InitPosData
        {
            [HorizontalGroup, LabelText("地块")]
            public int mapIndex;
            [HorizontalGroup, LabelText("位置")]
            public int sliceIndex;
        }

        #region 玩家出战数据

        [Serializable]
        public class PlayerTroopData
        {
            //
            [CustomValueDrawer("_EditDrawRaidPlayerUnitType")]
            public EnumRaidPlayerUnitType playerUnitType;
            EnumRaidPlayerUnitType _EditDrawRaidPlayerUnitType(EnumRaidPlayerUnitType value)
            {
                value = (EnumRaidPlayerUnitType)EditorGUILayout.Popup("选择部队类型", (int)value, RaidLevelUtil.PlayerUnitTypeNames.GetNameList().ToArray());
                return value;
            }
            [Serializable]
            public class ForceData
            {
                [HorizontalGroup, LabelText("部队"), LabelWidth(35)]
                public int forceId;
                [HorizontalGroup, LabelText("地块"), LabelWidth(35)]
                public int mapIndex = -1;
                [HorizontalGroup, LabelText("位置"), LabelWidth(35)]
                public int sliceIndex = -1;
            }
            public ForceData[] forceDatas;
        }
        [FoldoutGroup("玩家出战数据")]
        [HideLabel]
        public PlayerTroopData playerTroopData;
        [FoldoutGroup("玩家出战数据")]
        [Button("预览", ButtonSizes.Medium)]
        void EditUpdatePlayerUnitForcePos()
        {
            _UpdatePlayerUnitForcePos();
        }

        #endregion

        #region 固定出战部队

        [Serializable]
        public class FixedTroopData
        {
            [Serializable]
            public class ForceData
            {
                [HorizontalGroup, LabelText("部队"), LabelWidth(35)]
                public int forceId;
                [HorizontalGroup, LabelText("地块"), LabelWidth(35)]
                public int mapIndex = -1;
                [HorizontalGroup, LabelText("位置"), LabelWidth(35)]
                public int sliceIndex = -1;

                [HorizontalGroup, Button("选择")]
                void EditOpenSelectForcePanel()
                {
                    EditSelectPanel.Open(EnumConfigName.Force, (value) =>
                    {
                        //Debug.Log("select " + value);
                        forceId = value;
                    });
                }
            }
            public ForceData[] forceDatas;
        }
        [FoldoutGroup("固定出战部队数据")]
        [HideLabel]
        public FixedTroopData fixedTroopData;
       
        [FoldoutGroup("固定出战部队数据")]
        [Button("预览", ButtonSizes.Medium)]
        void EditUpdateFixedForcePos()
        {
            _UpdateFixedForcePos();
        }

        #endregion

        [Button("加载副本", ButtonSizes.Medium)]
        void EditLoadRaidLevel()
        {
            var message = $"确认加载副本{id}吗？将会覆盖当前prefab中的数据";
            if (!EditorUtility.DisplayDialog("", message, "OK", "Cancel"))
            {
                return;
            }
            var success = _LoadRaidLevel();
            if (success)
            {
                EditorUtility.DisplayDialog("", $"副本{id}加载成功", "OK");
            }
            else
            {
                EditorUtility.DisplayDialog("", $"副本{id}加载失败，详情见console", "OK");
            }
        }

        [Button("保存副本", ButtonSizes.Medium)]
        void EditSaveRaidLevel()
        {
            var success = _SaveRaidLevel();
            if (success)
            {
                EditorUtility.DisplayDialog("", $"副本{id}保存成功", "OK");
            }
            else
            {
                EditorUtility.DisplayDialog("", $"副本{id}保存失败，详情见console", "OK");
            }
        }

        public void SetData(RaidLevelInfo data)
        {
            try
            {
                id = data.id;
                sizeW = data.sizeW;
                sizeH = data.sizeH;
                map = data.map;
                mapBasic = data.mapBasic;
                mapInitRes = data.mapInitRes;
                mapEvent = data.mapEvent;

                levelName = data.levelName;
                levelNum = data.levelNum;
                cameraStartPos = data.cameraStartPos;

                playerTroopData = new PlayerTroopData();
                _SetData(data, playerTroopData);

                fixedTroopData = new FixedTroopData();
                _SetData(data, fixedTroopData);

                _UpdateLevelName();
                _UpdateLevelNum();
                _UpdatePlayerUnitForcePos();
                _UpdateFixedForcePos();

                _CreateMap();
                _CreateEvent();
            }
            catch (Exception e)
            {
                Debug.LogError(e.ToString());
            }
        }
        public void GetData(ref RaidLevelInfo data)
        {
            data.levelName = levelName;
            data.levelNum = levelNum;
            data.cameraStartPos = cameraStartPos;
            _GetData(data, playerTroopData);
            _GetData(data, fixedTroopData);
        }
        public void Reset()
        {
            int count = transform.childCount;
            for (int i = count - 1; i >= 0; --i)
            {
                DestroyImmediate(transform.GetChild(i).gameObject);
            }
        }

        protected string m_configRoot
        {
            get
            {
                return RaidLevelUtil.GetConfigRoot();
            }
        }

        protected ConfigBase<MapInfo> m_mapConfigCache;
        protected ConfigBase<MapInfo> _GetMapConfig(bool reload = false)
        {
            if (m_mapConfigCache == null)
            {
                m_mapConfigCache = new ConfigBase<MapInfo>();
                reload = true;
            }
            if (reload)
            {
                m_mapConfigCache.Reset();
                m_mapConfigCache.Load($"{Application.dataPath}/{m_configRoot}/mapConfig/{map}.xlsx");
            }
            return m_mapConfigCache;
        }
        protected ConfigBase<MapBasicInfo> m_mapBasicConfigCache;
        protected ConfigBase<MapBasicInfo> _GetMapBasicConfig(bool reload = false)
        {
            if (m_mapBasicConfigCache == null)
            {
                m_mapBasicConfigCache = new ConfigBase<MapBasicInfo>();
                reload = true;
            }
            if (reload)
            {
                m_mapBasicConfigCache.Reset();
                m_mapBasicConfigCache.Load($"{Application.dataPath}/{m_configRoot}/mapConfig/{mapBasic}.xlsx");
            }
            return m_mapBasicConfigCache;
        }

        private const string m_MapRootObjName = "MapRoot";
        private const string m_DecorateRootObjName = "DecorateRoot";
        private const string m_MapGridObjName = "MapGrid";

        void _CreateMap()
        {
            var mapConfig = _GetMapConfig();
            var mapBasicConfig = _GetMapBasicConfig();
            if (!mapConfig.IsLoaded || !mapBasicConfig.IsLoaded)
                return;
            var keys = mapConfig.GetKeys();
            float size = RaidLevelConst.MapUnitWidth;
            float halfSize = size * 0.5f;
            float halfTotalSizeW = sizeW * size * 0.5f;
            float halfTotalSizeH = sizeH * size * 0.5f;

            var mapRootGo = new GameObject(m_MapRootObjName);
            var mapRoot = mapRootGo.transform;
            mapRoot.SetParent(transform);
            mapRoot.localPosition = new Vector3(-halfTotalSizeW, 0f, -halfTotalSizeH);
            var decorateRoot = new GameObject(m_DecorateRootObjName).transform;
            decorateRoot.SetParent(transform);
            decorateRoot.localPosition = new Vector3(-halfTotalSizeW + halfSize, 0f, -halfTotalSizeH + halfSize);

            for (int i = 0; i < keys.Count; ++i)
            {
                var key = keys[i];
                var mapRawData = mapConfig.GetConfigItem(key) as MapInfo;
                if (mapRawData == null)
                    continue;
                var mapBasicRawData = mapBasicConfig.GetConfigItem(key) as MapBasicInfo;
                if (mapBasicRawData == null)
                    continue;

                var x = key % sizeW;
                var z = key / sizeW;
                var assetPath = $"{RaidLevelConst.MapUnitsPath}/MapUnit_{mapRawData.resource}.prefab";
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                if (prefab == null)
                {
                    Debug.LogError($"资源不存在 {assetPath}");
                    continue;
                }
                var go = Instantiate(prefab, mapRoot);
                go.name = $"{m_MapGridObjName}_{key}";
                go.transform.localPosition = new Vector3(halfSize + x * size, 0f, halfSize + z * size);
                var mapGridMono = go.AddComponent<MapGridMono>();
                mapGridMono.SetData(key, mapRawData, mapBasicRawData, decorateRoot);
            }

            RaidLevelUtil.SetLayer(decorateRoot, RaidLevelConst.IgnoreSeletLayer);
        }

        private const string m_EventRootObjName = "EventRoot";

        void _CreateEvent()
        {
            var mapEventRoot = transform.Find(m_EventRootObjName);
            if (mapEventRoot != null)
            {
                return;
            }
            GameObject mapEventGo = new GameObject(m_EventRootObjName);
            mapEventGo.transform.SetParent(transform);
            var mapEventMono = mapEventGo.AddComponent<MapEventMono>();
            mapEventMono.Init(mapEvent, sizeW, sizeH);
        }

        //加载副本
        bool _LoadRaidLevel()
        {
            var raidLevelRawData = ConfigManager.instance.GetItem<RaidLevelInfo>(EnumConfigName.RaidLevel, id);
            if (raidLevelRawData == null)
            {
                EditorUtility.DisplayDialog("", $"没有找到副本{id}!!", "OK");
                return false;
            }
            Reset();
            SetData(raidLevelRawData);
            return true;
        }

        //保存副本
        bool _SaveRaidLevel()
        {
            var mapConfig = _GetMapConfig(true);
            var mapBasicConfig = _GetMapBasicConfig(true);
            if (!mapConfig.IsLoaded || !mapBasicConfig.IsLoaded)
            {
                return false;
            }
            var raidLevelConfig = ConfigManager.instance.GetConfig(EnumConfigName.RaidLevel);
            if (raidLevelConfig == null)
                return false;
            var raidLevelInfo = raidLevelConfig.GetConfigItem(id) as RaidLevelInfo;
            if (raidLevelInfo == null)
                return false;
            GetData(ref raidLevelInfo);

            if (!raidLevelConfig.Save())
                return false;

            var transMapRoot = transform.Find(m_MapRootObjName);
            if (transMapRoot != null)
            {
                try
                {
                    foreach (Transform child in transMapRoot)
                    {
                        var name = child.name;
                        var id = int.Parse(name.Substring(name.IndexOf('_') + 1));
                        var mapInfo = mapConfig.GetConfigItem(id) as MapInfo;
                        var mapBasicInfo = mapBasicConfig.GetConfigItem(id) as MapBasicInfo;
                        if (mapInfo == null)
                        {
                            Debug.LogError($"MapConfig没有id{id}");
                            return false;
                        }
                        if (mapBasicInfo == null)
                        {
                            Debug.LogError($"MapBasicConfig没有id{id}");
                            return false;
                        }
                        var mono = child.GetComponent<MapGridMono>();
                        mono.GetData(ref mapInfo, ref mapBasicInfo);
                    }
                    if (!mapConfig.Save())
                        return false;
                    if (!mapBasicConfig.Save())
                        return false;
                }
                catch (Exception e)
                {
                    Debug.LogError(e.ToString());
                    return false;
                }
            }
            return true;
        }

        //副本名字
        private void _UpdateLevelName()
        {
            var languageConfig = ConfigManager.instance.GetConfig(EnumConfigName.LanguageConfig) as ConfigBase<LanguageConfigInfo>;
            var info = languageConfig.GetItem(levelName);
            if (info != null)
            {
                levelNameCnStr = info.descCN;
            }
            else
            {
                levelNameCnStr = "无";
            }
        }
        //副本关卡号
        private void _UpdateLevelNum()
        {
            var languageConfig = ConfigManager.instance.GetConfig(EnumConfigName.LanguageConfig) as ConfigBase<LanguageConfigInfo>;
            var info = languageConfig.GetItem(levelNum);
            if (info != null)
            {
                levelNumCnStr = info.descCN;
            }
            else
            {
                levelNumCnStr = "无";
            }
        }

        #region 玩家出生点

        private string m_PlayerSpawnRootName = "PlayerSpawnRoot";
        private string m_PlayerSpawnName = "PlayerSpawn";
        private List<GameObject> m_PlayerSpawns = new List<GameObject>();

        //
        private void _UpdatePlayerUnitForcePos()
        {
            _FindPlayerSpawns();
            _RemovePlayerSpawns();
            _CreatePlayerSpawns();
        }
        void _FindPlayerSpawns()
        {
            if (m_PlayerSpawns.Count > 0)
                return;
            var root = transform.Find(m_PlayerSpawnRootName);
            if (root == null)
                return;
            foreach (Transform child in root)
            {
                if (child.name.StartsWith(m_PlayerSpawnName))
                {
                    m_PlayerSpawns.Add(child.gameObject);
                }
            }
        }
        void _RemovePlayerSpawns()
        {
            foreach (var go in m_PlayerSpawns)
            {
                DestroyImmediate(go);
            }
            m_PlayerSpawns.Clear();
        }
        void _CreatePlayerSpawns()
        {
            var mapBasicConfig = _GetMapBasicConfig();
            if (mapBasicConfig == null || !mapBasicConfig.IsLoaded)
            {
                Debug.LogError($"{mapBasic} 没有加载");
                return;
            }
            if (playerTroopData == null || playerTroopData.forceDatas == null)
                return;
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(RaidLevelConst.PlayerForceSpawnPath);
            if (prefab == null)
                return;
            var root = transform.Find(m_PlayerSpawnRootName);
            if (root == null)
            {
                root = new GameObject(m_PlayerSpawnRootName).transform;
                root.SetParent(transform);
            }
            float totalW = RaidLevelConst.MapUnitWidth * sizeW;
            float totalH = RaidLevelConst.MapUnitWidth * sizeH;
            for (int i = 0; i < playerTroopData.forceDatas.Length; ++i)
            {
                if (playerTroopData.forceDatas == null)
                    continue;
                var troopData = playerTroopData.forceDatas[i];
                if (troopData.mapIndex < 0 || troopData.sliceIndex < 0)
                    continue;
                var go = GameObject.Instantiate(prefab, root);
                go.name = $"{m_PlayerSpawnName}_{i}";

                var mapIndex = troopData.mapIndex;
                var mapGridPos = RaidLevelUtil.GetGridPos(mapIndex, sizeW, totalW);
                mapGridPos.x -= totalW * 0.5f;
                mapGridPos.y -= totalH * 0.5f;

                var mapBasicInfo = mapBasicConfig.GetItem(mapIndex);
                if (mapBasicInfo == null)
                {
                    Debug.LogError($"{mapBasic} 没有配置的地块{mapIndex}");
                    continue;
                }
                int gridIndex = RaidLevelUtil.GetMapUnitGrid(mapBasicInfo.mapBasicInfoID, troopData.sliceIndex);

                var sliceGridPos = RaidLevelUtil.GetGridPos(gridIndex, RaidLevelConst.MapUnitGridCount, RaidLevelConst.MapUnitWidth);
                sliceGridPos.x -= RaidLevelConst.MapUnitWidth * 0.5f;
                sliceGridPos.y -= RaidLevelConst.MapUnitWidth * 0.5f;
                var pos = mapGridPos + sliceGridPos;
                go.transform.position = new Vector3(pos.x, 0f, pos.y);

                RaidLevelUtil.SetLayer(go.transform, RaidLevelConst.IgnoreSeletLayer);
            }
        }

        #endregion

        #region 固定部队出生点

        private string m_FixedForceSpawnRootName = "FixedForceSpawnRoot";
        private string m_FixedForceSpawnName = "FixedForceSpawn";
        private List<GameObject> m_FixedForceSpawns = new List<GameObject>();

        //
        private void _UpdateFixedForcePos()
        {
            _FindFixedForceSpawns();
            _RemoveFixedForceSpawns();
            _CreateFixedForceSpawns();
        }
        void _FindFixedForceSpawns()
        {
            if (m_FixedForceSpawns.Count > 0)
                return;
            var root = transform.Find(m_FixedForceSpawnRootName);
            if (root == null)
                return;
            foreach (Transform child in root)
            {
                if (child.name.StartsWith(m_FixedForceSpawnName))
                {
                    m_FixedForceSpawns.Add(child.gameObject);
                }
            }
        }
        void _RemoveFixedForceSpawns()
        {
            foreach (var go in m_FixedForceSpawns)
            {
                DestroyImmediate(go);
            }
            m_FixedForceSpawns.Clear();
        }
        void _CreateFixedForceSpawns()
        {
            var mapBasicConfig = _GetMapBasicConfig();
            if (mapBasicConfig == null || !mapBasicConfig.IsLoaded)
            {
                Debug.LogError($"{mapBasic} 没有加载");
                return;
            }
            if (fixedTroopData == null || fixedTroopData.forceDatas == null)
                return;
            var root = transform.Find(m_FixedForceSpawnRootName);
            if (root == null)
            {
                root = new GameObject(m_FixedForceSpawnRootName).transform;
                root.SetParent(transform);
            }
            var bottomPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(RaidLevelConst.FixedForceSpawnPath);

            float totalW = RaidLevelConst.MapUnitWidth * sizeW;
            float totalH = RaidLevelConst.MapUnitWidth * sizeH;
            var configManager = ConfigManager.instance;
            for (int i = 0; i < fixedTroopData.forceDatas.Length; ++i)
            {
                if (fixedTroopData.forceDatas == null)
                    continue;
                var forceData = fixedTroopData.forceDatas[i];

                var forceId = forceData.forceId;
                var forceInfo = configManager.GetItem<ForceInfo>(EnumConfigName.Force, forceId);
                if (forceInfo == null || string.IsNullOrEmpty(forceInfo.division))
                    continue;
                var divisionIds = forceInfo.division.Split('|');
                if (divisionIds.Length < 1)
                    continue;
                var divisionId = int.Parse(divisionIds[0]); //这里只取第一个单位，因为固定出战的部队只会包含一个单位（同玩家的部队）
                var divisionInfo = configManager.GetItem<DivisionInfo>(EnumConfigName.Division, divisionId);
                if (divisionInfo == null)
                    continue;
                int brigadeInt = int.Parse(divisionInfo.brigade);
                var unitLevelInfo = configManager.GetItem<UnitLevelInfo>(EnumConfigName.UnitLevel, brigadeInt);
                if (unitLevelInfo == null)
                    continue;
                var unitInfo = configManager.GetItem<UnitInfo>(EnumConfigName.Unit, unitLevelInfo.unitId);
                if (unitInfo == null)
                    continue;
                var assetPath = $"{RaidLevelConst.UnitAssetPath}/{unitInfo.resource}.prefab";
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
                if (prefab == null)
                {
                    Debug.LogError($"没有资源 {assetPath}");
                    continue;
                }
                var go = Instantiate(prefab, root);
                go.name = $"{m_FixedForceSpawnName}_{forceId}";

                if (bottomPrefab != null)
                {
                    Instantiate(bottomPrefab, go.transform);
                }
                var mapIndex = forceData.mapIndex;
                var mapGridPos = RaidLevelUtil.GetGridPos(mapIndex, sizeW, totalW);
                mapGridPos.x -= totalW * 0.5f;
                mapGridPos.y -= totalH * 0.5f;

                var mapBasicInfo = mapBasicConfig.GetItem(mapIndex);
                if (mapBasicInfo == null)
                {
                    Debug.LogError($"{mapBasic} 没有配置的地块{mapIndex}");
                    continue;
                }
                int gridIndex = RaidLevelUtil.GetMapUnitGrid(mapBasicInfo.mapBasicInfoID, forceData.sliceIndex);

                var sliceGridPos = RaidLevelUtil.GetGridPos(gridIndex, RaidLevelConst.MapUnitGridCount, RaidLevelConst.MapUnitWidth);
                sliceGridPos.x -= RaidLevelConst.MapUnitWidth * 0.5f;
                sliceGridPos.y -= RaidLevelConst.MapUnitWidth * 0.5f;
                var pos = mapGridPos + sliceGridPos;
                go.transform.position = new Vector3(pos.x, 0f, pos.y);

                RaidLevelUtil.SetLayer(go.transform, RaidLevelConst.IgnoreSeletLayer);
                m_FixedForceSpawns.Add(go);
            }
        }

        #endregion


        #region 其他解析函数

        private void _SetData(RaidLevelInfo info, PlayerTroopData playerTroopData)
        {
            playerTroopData.playerUnitType = (EnumRaidPlayerUnitType)info.playerUnitType;

            if (string.IsNullOrEmpty(info.playerUnitForceID) || string.IsNullOrEmpty(info.playerUnitForcePos))
                return;

            var troopNum = info.playerUnitCount;
            var troopIds = RaidLevelUtil.UnpackIntArray(info.playerUnitForceID, '|');
            var troopPos = info.playerUnitForcePos.Split('#');

            int count = Mathf.Max(troopNum, Mathf.Max(troopIds.Length, troopPos.Length));
            playerTroopData.forceDatas = new PlayerTroopData.ForceData[count];
            for (int i = 0; i < count; ++i)
            {
                var forceData = new PlayerTroopData.ForceData();
                if (i < troopIds.Length)
                {
                    forceData.forceId = troopIds[i];
                }
                if (i < troopPos.Length)
                {
                    var temp = troopPos[i].Split('|');
                    if (temp.Length == 2)
                    {
                        forceData.mapIndex = int.Parse(temp[0]);
                        forceData.sliceIndex = int.Parse(temp[1]);
                    }
                }
                playerTroopData.forceDatas[i] = forceData;
            }
        }
        private void _GetData(RaidLevelInfo info, PlayerTroopData playerTroopData)
        {
            if (playerTroopData == null)
                return;
            if (playerTroopData.forceDatas == null || playerTroopData.forceDatas.Length < 1)
            {
                info.playerUnitCount = 0;
                info.playerUnitForceID = string.Empty;
                info.playerUnitForcePos = string.Empty;
                return;
            }
            int count = playerTroopData.forceDatas.Length;
            info.playerUnitCount = count;

            var troopIds = new int[count];
            var troopPos = new string[count];
            for (int i = 0; i < count; ++i)
            {
                var troopData = playerTroopData.forceDatas[i];
                troopIds[i] = troopData.forceId;
                troopPos[i] = $"{troopData.mapIndex}|{troopData.sliceIndex}";
            }
            info.playerUnitForceID  = RaidLevelUtil.PackArray(troopIds, '|');
            info.playerUnitForcePos = RaidLevelUtil.PackArray(troopPos, '#');
        }

        private void _SetData(RaidLevelInfo info, FixedTroopData fixedTroopData)
        {
            if (string.IsNullOrEmpty(info.fixedTroopID) || string.IsNullOrEmpty(info.fixedTroopPos))
                return;
            var troopIds = RaidLevelUtil.UnpackIntArray(info.fixedTroopID, '|');
            var troopPos = info.fixedTroopPos.Split('#');

            int count = Mathf.Max(troopIds.Length, troopPos.Length);
            fixedTroopData.forceDatas = new FixedTroopData.ForceData[count];
            for (int i = 0; i < count; ++i)
            {
                var forceData = new FixedTroopData.ForceData();
                if (i < troopIds.Length)
                {
                    forceData.forceId = troopIds[i];
                }
                if (i < troopPos.Length)
                {
                    var temp = troopPos[i].Split('|');
                    if (temp.Length == 2)
                    {
                        forceData.mapIndex = int.Parse(temp[0]);
                        forceData.sliceIndex = int.Parse(temp[1]);
                    }
                }
                fixedTroopData.forceDatas[i] = forceData;
            }
        }
        private void _GetData(RaidLevelInfo info, FixedTroopData fixedTroopData)
        {
            if (fixedTroopData == null)
                return;
            if (fixedTroopData.forceDatas == null || fixedTroopData.forceDatas.Length < 1)
            {
                info.fixedTroopID   = string.Empty;
                info.fixedTroopPos  = string.Empty;
                return;
            }
            int count = fixedTroopData.forceDatas.Length;

            var troopIds = new int[count];
            var troopPos = new string[count];
            for (int i = 0; i < count; ++i)
            {
                var troopData = fixedTroopData.forceDatas[i];
                troopIds[i] = troopData.forceId;
                troopPos[i] = $"{troopData.mapIndex}|{troopData.sliceIndex}";
            }
            info.fixedTroopID = RaidLevelUtil.PackArray(troopIds, '|');
            info.fixedTroopPos = RaidLevelUtil.PackArray(troopPos, '#');
        }

        #endregion
    }
}

#endif