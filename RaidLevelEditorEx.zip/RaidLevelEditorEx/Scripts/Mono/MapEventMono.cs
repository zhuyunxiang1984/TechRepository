using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public class MapEventMono : MonoBehaviour
    {
        [LabelText("�����¼�"), DisplayAsString]
        public string mapEvent;

        [HorizontalGroup, Button("�����¼�", ButtonSizes.Medium)]
        void LoadEvent()
        {
            if (EditorUtility.DisplayDialog("hint", "���ؽ��Ḳ�����е�prefab��ȷ����", "OK", "Cancel"))
            {
                if (!Load())
                {
                    EditorUtility.DisplayDialog("error", $"�¼�����ʧ�� {mapEvent}", "OK");
                }
                else
                {
                    EditorUtility.DisplayDialog("error", $"�¼����سɹ� {mapEvent}", "OK");
                }
            }
            
        }
        [HorizontalGroup, Button("�����¼�", ButtonSizes.Medium)]
        void SaveEvent()
        {
            if (EditorUtility.DisplayDialog("hint", "���潫�Ḳ�����е�excel��ȷ����", "OK", "Cancel"))
            {
                if (!Save())
                {
                    EditorUtility.DisplayDialog("error", $"�¼�����ʧ�� {mapEvent}", "OK");
                }
                else
                {
                    EditorUtility.DisplayDialog("error", $"�¼�����ɹ� {mapEvent}", "OK");
                }
            } 
        }

        [Button("�����¼�", ButtonSizes.Medium)]
        void CreateEvent()
        {
            var eventGo = new GameObject("Event");
            eventGo.transform.SetParent(transform);
            var eventData = eventGo.AddComponent<EventData>();
            eventData.SetMapData(m_SizeW, m_SizeH);
        }

        #region ���ñ�

        protected string m_configRoot
        {
            get
            {
                return RaidLevelUtil.GetConfigRoot();
            }
        }
        protected ConfigBase<EventInfo> m_eventConfigCache;
        protected ConfigBase<EventInfo> _GetEventConfig(bool reload = false)
        {
            if (m_eventConfigCache == null)
            {
                m_eventConfigCache = new ConfigBase<EventInfo>();
                reload = true;
            }
            if (reload)
            {
                m_eventConfigCache.Reset();
                m_eventConfigCache.Load($"{Application.dataPath}/{m_configRoot}/mapConfig/{mapEvent}.xlsx");
            }
            return m_eventConfigCache;
        }
        #endregion

        protected int m_SizeW, m_SizeH;
        public void Init(string mapEvent, int sizeW, int sizeH)
        {
            this.mapEvent = mapEvent;

            m_SizeW = sizeW;
            m_SizeH = sizeH;
        }

        public bool Load()
        {
            _ClearEvents();
            return _LoadEventInternal();
        }

        public bool Save()
        {
            return _SaveEventInternal();
        }

        //�����¼�
        protected void _ClearEvents()
        {
            int count = transform.childCount;
            for (int i = count - 1; i >= 0; --i)
            {
                DestroyImmediate(transform.GetChild(i).gameObject);
            }
        }

        //�����¼�
        protected bool _LoadEventInternal()
        {
            var mapEventConfig = _GetEventConfig(true);
            if (mapEventConfig == null || !mapEventConfig.IsLoaded)
                return false;
            var actions = new List<KeyValuePair<int, int>>();
            var keys = mapEventConfig.GetKeys();
            for (int i = 0; i < keys.Count; ++i)
            {
                var key = keys[i];
                var mapEventInfo = mapEventConfig.GetItem(key);
                if (mapEventInfo == null)
                    continue;

                actions.Clear();
                if (!string.IsNullOrEmpty(mapEventInfo.actionId) &&
                    !string.IsNullOrEmpty(mapEventInfo.actiontileId))
                {
                    var actionStr1 = mapEventInfo.actionId.Split('|');
                    var actionStr2 = mapEventInfo.actiontileId.Split('|');

                    for (int j = 0; j < actionStr1.Length && j < actionStr2.Length; ++j)
                    {
                        actions.Add(new KeyValuePair<int, int>(int.Parse(actionStr1[j]), int.Parse(actionStr2[j])));
                    }
                }

                //
                var eventGo = new GameObject("Event");
                eventGo.transform.SetParent(transform);
                var eventData = eventGo.AddComponent<EventData>();
                eventData.Init(mapEventInfo, actions);
                eventData.SetMapData(m_SizeW, m_SizeH);
            }
            return true;
        }

        //�����¼�
        protected bool _SaveEventInternal()
        {
            var mapEventConfig = _GetEventConfig(true);
            if (mapEventConfig == null || !mapEventConfig.IsLoaded)
                return false;
            mapEventConfig.ResetData();

            //�ռ��¼�
            var eventDatas = gameObject.GetComponentsInChildren<EventData>();
            for (int i = 0; i < eventDatas.Length; ++i)
            {
                var eventData = eventDatas[i];

                var eventInfo = new EventInfo();
                eventInfo.id = i + 1;
                eventInfo._ps = eventData._ps;
                eventInfo.triggerId = eventData.TriggerData.id;
                eventInfo.tileId = eventData.TriggerData.MapIndex;

                var temp1 = string.Empty;
                var temp2 = string.Empty;
                for (int j = 0; j < eventData.ActionDatas.Count; ++j)
                {
                    var actionData = eventData.ActionDatas[j];
                    if (j > 0)
                    {
                        temp1 += "|";
                        temp2 += "|";
                    }
                    temp1 += actionData.id;
                    temp2 += actionData.MapIndex;
                }
                eventInfo.actionId = temp1;
                eventInfo.actiontileId = temp2;

                mapEventConfig.AddItem(eventInfo.id, eventInfo);
            }
            return mapEventConfig.Save();
        }

        protected MapGridMono _GetMapGridMono(int mapIndex)
        {
            var node = transform.GetChild(mapIndex);
            if (node == null)
                return null;
            var mono = node.GetComponent<MapGridMono>();
            if (mono == null || mono.id != mapIndex)
                return null;
            return mono;
        }
    }
}
#endif
