﻿using System;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public class EditSelectPanel : EditorWindow
    {
        public static void Open(EnumConfigName configName, Action<int> OnSelect)
        {
            var window = GetWindow<EditSelectPanel>("选择项");
            window.Init(configName, OnSelect);
            window.minSize = new Vector2(620f, 800f);
            window.maxSize = window.minSize;
            window.Show();
        }

        protected EnumConfigName m_configName;
        protected Action<int> m_OnSelect;
        protected IConfigBase m_config;
        public void Init(EnumConfigName configName, Action<int> OnSelect)
        {
            m_configName = configName;
            m_OnSelect = OnSelect;
            m_config = ConfigManager.instance.GetConfig(configName);
        }

        private List<ConfigItem> m_showList = new List<ConfigItem>();
        private Vector2 m_scrollviewRect;
        private void OnGUI()
        {
            if (m_config == null)
                return;
            var keys = m_config.GetKeys();

            m_showList.Clear();
            for (int i = 0; i < keys.Count; ++i)
            {
                var info = m_config.GetConfigItem(keys[i]);
                if (info == null || !_IsAvaliable(info))
                    continue;
                m_showList.Add(info);
            }

            m_scrollviewRect = GUILayout.BeginScrollView(m_scrollviewRect);
            int colNum = 3;
            int rowNum = Mathf.CeilToInt(m_showList.Count * 1.0f / colNum);
            for (int row = 0; row < rowNum; ++row)
            {
                GUILayout.BeginHorizontal();
                for (int col = 0; col < colNum; ++col)
                {
                    int index = row * colNum + col;
                    if (index >= m_showList.Count)
                        continue;
                    var info = m_showList[index];                    
                    if (GUILayout.Button(_GetDisplayName(info), GUILayout.Width(200)))
                    {
                        m_OnSelect?.Invoke(info.id);
                        Close();
                    }
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();
            
        }

        //是否显示该项
        private bool _IsAvaliable(ConfigItem info)
        {
            if (m_configName == EnumConfigName.Item)
            {
                var itemInfo = info as ItemInfo;
                if (string.IsNullOrEmpty(itemInfo.modelID) || itemInfo.modelID == "0")
                    return false;
            }
            return true;
        }

        //获取显示名称
        private string _GetDisplayName(ConfigItem info)
        {
            if (m_configName == EnumConfigName.BuildingBasic)
            {
                return $"{info.id}:{(info as BuildingBasicInfo)._ps}";
            }
            if (m_configName == EnumConfigName.Force)
            {
                return $"{info.id}:{(info as ForceInfo)._ps1}";
            }
            if (m_configName == EnumConfigName.Item)
            {
                return $"{info.id}:{(info as ItemInfo)._ps}";
            }
            return info.id.ToString();
        }
    }

}

#endif