using System;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public class EditEventActionPanel : EditorWindow
    {
        public static void Open(int actionId, Action<EventActionInfo> onSave = null)
        {
            var window = GetWindow<EditEventActionPanel>("�༭��Ϊ");
            window.Init(actionId, onSave);
            window.minSize = new Vector2(620f, 800f);
            window.maxSize = window.minSize;
            window.Show();
        }

        protected EventActionInfo m_Info;
        protected Action<EventActionInfo> m_OnSave;
        protected ConfigBase<EventActionInfo> m_Config;
        
        public void Init(int actionId, Action<EventActionInfo> onSave = null)
        {
            m_OnSave = onSave;
            m_Config = ConfigManager.instance.GetConfig(EnumConfigName.EventAction) as ConfigBase<EventActionInfo>;
            m_Info = m_Config.GetItem(actionId);
        }
        private void OnGUI()
        {
            EditorGUILayout.LabelField($"��ΪId: {m_Info.id}");
            m_Info._ps  = EditorGUILayout.TextField("_ps", m_Info._ps);
            m_Info.type = EditorGUILayout.Popup("��Ϊ����", m_Info.type, RaidLevelUtil.ActionTypeNames.GetNameList().ToArray());

            if (IsShow(m_Info.type, "forceGroup"))   m_Info.forceGroup   = EditorGUILayout.IntField("ָ��Force��", m_Info.forceGroup);
            if (IsShow(m_Info.type, "troopsType"))   m_Info.troopsType   = EditorGUILayout.IntField("��������", m_Info.troopsType);
            if (IsShow(m_Info.type, "playerTroops")) m_Info.playerTroops = EditorGUILayout.IntField("��Ҳ�����", m_Info.playerTroops);
            if (IsShow(m_Info.type, "terrainGroup")) m_Info.terrainGroup = EditorGUILayout.TextField("ָ���ؿ���ƫ�ƶ�", m_Info.terrainGroup);

            if (IsShow(m_Info.type, "building"))        m_Info.building      = EditorGUILayout.IntField("ָ������", m_Info.building);
            if (IsShow(m_Info.type, "troopParaType"))   m_Info.troopParaType = EditorGUILayout.IntField("���Ӳ�������", m_Info.troopParaType);
            if (IsShow(m_Info.type, "num"))             m_Info.num           = EditorGUILayout.IntField("��������", m_Info.num);
            if (IsShow(m_Info.type, "phrase"))          m_Info.phrase        = EditorGUILayout.TextField("�����Ի�ID", m_Info.phrase);

            if (IsShow(m_Info.type, "buff"))        m_Info.buff         = EditorGUILayout.IntField("Buff", m_Info.buff);
            if (IsShow(m_Info.type, "timeLast"))    m_Info.timeLast     = EditorGUILayout.FloatField("����ʱ����", m_Info.timeLast);
            if (IsShow(m_Info.type, "side"))        m_Info.side         = EditorGUILayout.IntField("�ؿ����", m_Info.side);
            if (IsShow(m_Info.type, "showEfects"))  m_Info.showEfects   = EditorGUILayout.TextField("�ؿ��Ϲұ���", m_Info.showEfects);

            if (GUILayout.Button("����"))
            {
                m_Config.Save();
                m_OnSave?.Invoke(m_Info);
                Close();
            }
        }

        private static bool IsShow(int type, string propName)
        {
            var dict = RaidLevelUtil.ActionTypeProperties;
            if (dict.ContainsKey(type) && !dict[type].Contains(propName))
                return false;
            return true;
        }

    }


}

#endif