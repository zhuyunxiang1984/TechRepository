using System;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public class EditEventTriggerPanel : EditorWindow
    {
        public static void Open(int triggerId, Action<EventTriggerInfo> onSave = null)
        {
            var window = GetWindow<EditEventTriggerPanel>("�༭����");
            window.Init(triggerId, onSave);
            window.minSize = new Vector2(620f, 800f);
            window.maxSize = window.minSize;
            window.Show();
        }


        protected EventTriggerInfo m_Info;
        protected Action<EventTriggerInfo> m_OnSave;
        protected ConfigBase<EventTriggerInfo> m_Config;
        public void Init(int triggerId, Action<EventTriggerInfo> onSave = null)
        {
            m_OnSave = onSave;
            m_Config = ConfigManager.instance.GetConfig(EnumConfigName.EventTrigger) as ConfigBase<EventTriggerInfo>;
            m_Info = m_Config.GetItem(triggerId);
        }
        private void OnGUI()
        {
            EditorGUILayout.LabelField($"����Id: {m_Info.id}");
            m_Info._ps = EditorGUILayout.TextField("_ps", m_Info._ps);
            m_Info.type = EditorGUILayout.Popup("��������", m_Info.type, RaidLevelUtil.TriggerTypeNames.GetNameList().ToArray());

            if (IsShow(m_Info.type, "side"))            m_Info.side = EditorGUILayout.IntField("�ҷ�or�з�", m_Info.side);
            if (IsShow(m_Info.type, "forceGroup"))      m_Info.forceGroup = EditorGUILayout.TextField("ָ��Force��", m_Info.forceGroup);
            if (IsShow(m_Info.type, "playerTroops"))    m_Info.playerTroops = EditorGUILayout.IntField("��Ҳ�����", m_Info.playerTroops);
            if (IsShow(m_Info.type, "terrainGroup"))    m_Info.terrainGroup = EditorGUILayout.TextField("ָ���ؿ���ƫ�ƶ�", m_Info.terrainGroup);

            if (IsShow(m_Info.type, "unitSelect"))      m_Info.unitSelect = EditorGUILayout.IntField("ȫ��or���ⲿ�ӿɴ���", m_Info.unitSelect);
            if (IsShow(m_Info.type, "state"))           m_Info.state = EditorGUILayout.IntField("����״̬�仯", m_Info.state);
            if (IsShow(m_Info.type, "resource"))        m_Info.resource = EditorGUILayout.IntField("��Դ����", m_Info.resource);
            if (IsShow(m_Info.type, "mathMark"))        m_Info.mathMark = EditorGUILayout.IntField("�Ƚ�����", m_Info.mathMark);

            if (IsShow(m_Info.type, "value"))           m_Info.value = EditorGUILayout.IntField("Ŀ��ֵ", m_Info.value);
            if (IsShow(m_Info.type, "delayTime"))       m_Info.delayTime = EditorGUILayout.FloatField("�ӳ�ʱ����", m_Info.delayTime);
            if (IsShow(m_Info.type, "triggerTimes"))    m_Info.triggerTimes = EditorGUILayout.IntField("һ�������еĿɴ�������", m_Info.triggerTimes);

            if (GUILayout.Button("����"))
            {
                m_Config.Save();
                m_OnSave?.Invoke(m_Info);
                Close();
            }
        }

        private static bool IsShow(int type, string propName)
        {
            var dict = RaidLevelUtil.TriggerTypeProperties;
            if (dict.ContainsKey(type) && !dict[type].Contains(propName))
                return false;
            return true;
        }
    }


}

#endif