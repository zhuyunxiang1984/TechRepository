﻿using System;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public static class RaidLevelConst
    {
        public static string RaidLevelEditorConfigRootKey = "RaidLevelEditorConfigRootKey";
        public static string RaidLevelEditorConfigRootDefault = "../../Designer/GameConfig";

        public const int IgnoreSeletLayer = 31;
        
        public static readonly string MapBuidingPath    = "Assets/GameResources/Game/Building";
        public static readonly string UnitAssetPath = "Assets/GameResources/Game/Unit";
        public static readonly string ItemAssetPath = "Assets/GameResources/Game/Objects";
        public static readonly string EffectAssetPath = "Assets/GameResources/Game/Effects";

        public const int IconSize = 16;
        public const int IconPadding = 5;
        public static readonly string EventIcon = "Assets/RaidLevelEditorEx/Editor/Textures/event_icon.png";

        //每个地块的宽度
        public static readonly float MapUnitWidth = 361f;
        //每个地块的细分格子
        public static readonly int MapUnitGridCount = 19;
        public static readonly string MapUnitsPath = "Assets/GameResources/Game/Map/MapUnits";
        public static readonly string[] MapDecoratePath = new string[] 
        {
            "Assets/GameResources/Game/Map/Decorate/Applique",
            "Assets/GameResources/Game/Map/Decorate/Building",
            "Assets/GameResources/Game/Map/Decorate/Mountain",
            "Assets/GameResources/Game/Map/Decorate/Object",
            "Assets/GameResources/Game/Map/Decorate/Road",
            "Assets/GameResources/Game/Map/Decorate/Vegetation",
        };
        
        //不可行走区域的表现
        public static readonly string UnwalkablePath = "Assets/RaidLevelEditorEx/Prefab/Unwalkable.prefab";
        //玩家部队出生点
        public static readonly string PlayerForceSpawnPath = "Assets/RaidLevelEditorEx/Prefab/PlayerForceSpawn.prefab";
        //固定部队出生点
        public static readonly string FixedForceSpawnPath = "Assets/RaidLevelEditorEx/Prefab/FixedForceSpawn.prefab";
    }

    public static class RaidLevelUtil
    {
        public static string GetConfigRoot()
        {
            return EditorPrefs.GetString(RaidLevelConst.RaidLevelEditorConfigRootKey, RaidLevelConst.RaidLevelEditorConfigRootDefault);
        }
        public static void LoadConfigs(bool forceReload, bool silence = false)
        {
            XDebug.Log("GGYY", "加载配置...");
            var configRoot = GetConfigRoot();
            if (string.IsNullOrEmpty(configRoot))
                return;
            int count = (int)EnumConfigName.Count;
            bool success = false;
            for (int i = 0; i < count; ++i)
            {
                var configName = (EnumConfigName)i;
                var config = ConfigManager.instance.GetConfig(configName);
                if (config != null && config.IsLoaded && !forceReload)
                    continue;
                success = ConfigManager.instance.Load(configName, configRoot);
                if (!success)
                {
                    EditorUtility.DisplayDialog("", $"配置表{configName}加载失败，详情见consle，稍后请手动加载", "OK");
                    return;
                }
            }
            XDebug.Log("GGYY", "加载配置成功!");
            if (!silence)
            {
                EditorUtility.DisplayDialog("", $"配置表已重新加载", "OK");
            }
        }
        public static void SetLayer(Transform root, int layer, bool recursively = true)
        {
            root.gameObject.layer = layer;
            if (recursively && root.childCount > 0)
            {
                foreach (Transform child in root)
                {
                    SetLayer(child, layer, true);
                }
            }
        }

        public static int[] UnpackIntArray(string text, char c)
        {
            var splitStr = text.Split(c);
            if (splitStr == null || splitStr.Length < 1)
                return null;
            int[] result = new int[splitStr.Length];
            try
            {
                for (int i = 0; i < splitStr.Length; ++i)
                {
                    result[i] = int.Parse(splitStr[i]);
                }
            }
            catch (Exception e)
            {
                Debug.LogError(e.ToString());
            }
            return result;
        }
        public static string PackArray<T>(T[] array, char c)
        {
            if (array == null || array.Length < 1)
                return string.Empty;
            int count = array.Length;
            var result = string.Empty;
            for (int i = 0; i < count; ++i)
            {
                if (i > 0)
                {
                    result += c;
                }
                result += array[i].ToString();
            }
            return result;
        }

        public static Vector2 GetGridPos(int count, int maxCount, float width)
        {
            float slice = width / maxCount;
            float halfSlice = slice * 0.5f;

            var col = count % maxCount;
            var row = count / maxCount;

            var result = Vector2.zero;
            result.x = col * slice + halfSlice;
            result.y = row * slice + halfSlice;
            return result;
        }
        static Dictionary<int, List<int>> m_MapUnitGridDatas = new Dictionary<int, List<int>>();
        //获取预设驻兵点信息
        public static List<int> GetMapUnitGridList(int id)
        {
            List<int> mapUnitGridData = null;
            if (m_MapUnitGridDatas.ContainsKey(id))
            {
                mapUnitGridData = m_MapUnitGridDatas[id];
            }
            else
            {
                mapUnitGridData = new List<int>();
                var info = ConfigManager.instance.GetItem<MapBasicInfoInfo>(EnumConfigName.MapBasicInfo, id);
                if (info == null)
                    return null;
                try
                {
                    var array = info.defendPoint.Split(';');
                    for (int i = 0; i < array.Length; ++i)
                    {
                        mapUnitGridData.Add(int.Parse(array[i].Split(',')[1]));
                    }
                    m_MapUnitGridDatas.Add(id, mapUnitGridData);
                }
                catch (Exception e)
                {
                }
            }
            return mapUnitGridData;
        }
        public static int GetMapUnitGrid(int id, int index)
        {
            var list = GetMapUnitGridList(id);
            if (list == null)
                return 0;
            if (index < 0 || index >= list.Count)
                return 0;
            return list[index];
        }

        #region 枚举子串定义

        public static EnumPopupHelper GroundTypeNames { get; private set; } = new EnumPopupHelper((int)MapType.count,
            new Dictionary<int, string>()
            {
                { (int)MapType.obstancle     , "障碍物" },
                { (int)MapType.free          , "空地" },
                { (int)MapType.player        , "玩家占领" },
                { (int)MapType.npc           , "NPC占领" },
                { (int)MapType.npc_resource  , "资源建筑的NPC占领" },
                { (int)MapType.ressource     , "资源地块类型" },
                { (int)MapType.nuclear       , "核弹类型" },
                { (int)MapType.camp          , "势力类型" },
                { (int)MapType.safe          , "安全区类型" },
                { (int)MapType.npc_resource_type , "资源地块类型,地块上有NPC" },
                { (int)MapType.plunder_build     , "掠夺建筑中心地块" },
                { (int)MapType.concentrate_point , "集结点" },
                { (int)MapType.plunder_resource  , "掠夺建筑资源" },
                { (int)MapType.statue            , "遗迹地块" },
                { (int)MapType.statue_tower      , "雕像范围防御塔" },
                { (int)MapType.statue_monster    , "雕像周围怪物" },
                { (int)MapType.raid_building     , "副本-只有中立建筑" },
                { (int)MapType.raid_building_npc , "副本-中立建筑和NPC" },
            }
            );

        public static EnumPopupHelper PlayerUnitTypeNames { get; private set; } = new EnumPopupHelper((int)EnumRaidPlayerUnitType.Count,
            new Dictionary<int, string>()
            {
                {(int)EnumRaidPlayerUnitType.None    , "无" },
                {(int)EnumRaidPlayerUnitType.Clone   , "镜像" },
                {(int)EnumRaidPlayerUnitType.Origin  , "原始" },
            });

        public static EnumPopupHelper TriggerTypeNames { get; private set; } = new EnumPopupHelper((int)EnumTriggerType.Count,
            new Dictionary<int, string>()
            {
                 {(int)EnumTriggerType.None    , "无" },
                 {(int)EnumTriggerType.UnitArrived    , "单位登陆或经过" },
                 {(int)EnumTriggerType.UnitMoniter    , "单位监视" },
                 {(int)EnumTriggerType.TimeMoniter    , "时间监视" },
                 {(int)EnumTriggerType.GameStart      , "关卡开始" },
            });
        public static Dictionary<int, List<string>> TriggerTypeProperties = new Dictionary<int, List<string>>()
        {
            {(int)EnumTriggerType.UnitArrived  , new List<string>(){ "side", "forceGroup", "terrainGroup", "unitSelect", "delayTime", "triggerTimes" } },
            {(int)EnumTriggerType.UnitMoniter  , new List<string>(){ "forceGroup", "unitSelect", "state", "delayTime", "triggerTimes" } },
            {(int)EnumTriggerType.TimeMoniter  , new List<string>(){ "delayTime", "triggerTimes" } },
            {(int)EnumTriggerType.GameStart    , new List<string>(){ "triggerTimes" } },

        };

        public static EnumPopupHelper ActionTypeNames { get; private set; } = new EnumPopupHelper((int)EnumActionType.Count,
            new Dictionary<int, string>()
            {
                 {(int)EnumActionType.None    , "无" },
                 {(int)EnumActionType.GenerateTroop     , "刷出部队" },
                 {(int)EnumActionType.ShowDialog        , "副本对话" },
                 {(int)EnumActionType.TroopMove         , "部队移动" },
                 {(int)EnumActionType.MapChangeOwner    , "地块归属转移" },
                 {(int)EnumActionType.OpenFog           , "开启迷雾" },
                 {(int)EnumActionType.AddEffect         , "添加地块效果" },
                 {(int)EnumActionType.DelEffect         , "删除地块效果" },
            });
        public static Dictionary<int, List<string>> ActionTypeProperties = new Dictionary<int, List<string>>()
        {
            {(int)EnumActionType.GenerateTroop  , new List<string>(){ "forceGroup", "troopsType", "terrainGroup", "forceGroup" } },
            {(int)EnumActionType.ShowDialog     , new List<string>(){ "phrase" } },
            {(int)EnumActionType.TroopMove      , new List<string>(){ "forceGroup", "terrainGroup" } },
            {(int)EnumActionType.MapChangeOwner , new List<string>(){ "side" } },
            {(int)EnumActionType.OpenFog        , new List<string>(){ "" } },
            {(int)EnumActionType.AddEffect      , new List<string>(){ "showEfects" } },
            {(int)EnumActionType.DelEffect      , new List<string>(){ "showEfects" } },
        };

        #endregion
    }

}

#endif