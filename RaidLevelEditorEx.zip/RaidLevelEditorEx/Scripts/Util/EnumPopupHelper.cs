﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace OWG.RaidLevelEditor
{
    public class EnumPopupHelper
    {
        private List<string> m_NameList = new List<string>();
        private int m_Count;
        private Dictionary<int, string> m_NameDict;
        public EnumPopupHelper(int count, Dictionary<int, string> data)
        {
            m_Count = count;
            m_NameDict = data;
        }
        public List<string> GetNameList()
        {
            if (m_NameList.Count > 0)
                return m_NameList;
            for (int i = 0; i < m_Count; ++i)
            {
                if (m_NameDict.ContainsKey(i))
                {
                    m_NameList.Add(m_NameDict[i]);
                }
                else
                {
                    m_NameList.Add(i.ToString());
                }
            }
            return m_NameList;
        }

    }
}