﻿using System;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

using NPOI.SS.UserModel;
#if UNITY_EDITOR
using NPOI.XSSF.UserModel;
#endif

namespace OWG.RaidLevelEditor
{
    public class ConfigRawData
    {
        protected string m_name;
        protected int m_fieldCount;
        protected string[] m_fieldTypes;
        protected string[] m_fieldNames;
        protected Dictionary<int, string[]> m_datas = new Dictionary<int, string[]>();
        protected Dictionary<string, int> m_dictFieldNames = new Dictionary<string, int>();

        public string[] FieldTypes => m_fieldTypes;
        public string[] FieldNames => m_fieldNames;
        public Dictionary<string, int> FieldNamesDict => m_dictFieldNames;

        public bool IsEmpty()
        {
            return m_datas == null || m_datas.Count < 1;
        }
        public void Reset()
        {
            m_name = string.Empty;
            m_fieldCount = 0;
            m_fieldTypes = null;
            m_fieldNames = null;
            m_dictFieldNames.Clear();
            m_datas.Clear();
        }
        public void ResetData()
        {
            m_datas.Clear();
        }
        public void Init(string name)
        {
            m_name = name;
        }
        public void SetFields(string[] fieldTypes, string[] fieldNames)
        {
            m_fieldCount = fieldTypes.Length;
            m_fieldTypes = fieldTypes;
            m_fieldNames = fieldNames;
            for (int i = 0; i < m_fieldCount; ++i)
            {
                m_dictFieldNames.Add(m_fieldNames[i], i);
            }
        }
        public void SetData(int id, string[] data)
        {
            if (m_datas.ContainsKey(id))
            {
                Debug.LogError($"{m_name} 重复id {id}");
                return;
            }
            if(data.Length != m_fieldCount)
            {
                Debug.LogError($"{m_name}  数据长度与字段数不相同 {id} field:{m_fieldCount} data:{data.Length}");
                return;
            }
            m_datas.Add(id, data);
        }
        public string[] GetData(int id)
        {
            if (m_datas.ContainsKey(id))
                return m_datas[id];
            return null;
        }
        public bool Exist(int id)
        {
            return m_datas.ContainsKey(id);
        }
    }
    public abstract class ConfigItem
    {
        public int id;
        public void Parse(Dictionary<string, int> fieldNames, string[] data)
        {
            Type type = GetType();
            var fieldInfos = type.GetFields();
            foreach (var fieldInfo in fieldInfos)
            {
                var fieldName = fieldInfo.Name;
                if (!fieldNames.ContainsKey(fieldName))
                {
                    Debug.LogError($"fieldName:{fieldName}不存在");
                    continue;
                }
                int index = fieldNames[fieldName];
                try
                {
                    if (fieldInfo.FieldType == typeof(int))
                    {
                        fieldInfo.SetValue(this, int.Parse(data[index]));
                    }
                    else if (fieldInfo.FieldType == typeof(float))
                    {
                        fieldInfo.SetValue(this, float.Parse(data[index]));
                    }
                    else if (fieldInfo.FieldType == typeof(string))
                    {
                        fieldInfo.SetValue(this, data[index]);
                    }
                    else
                    {
                        Debug.LogError($"类型异常 name:{fieldName} type:{fieldInfo.FieldType.Name}");
                        fieldInfo.SetValue(this, string.Empty);
                    }
                }
                catch (Exception e)
                {
                    Debug.LogError($"类型异常 name:{fieldName} type:{fieldInfo.FieldType.Name}");
                    Debug.LogError(e.ToString());
                }
            }
        }
        public void PackData(Dictionary<string, int> fieldNames, ref string[] data)
        {
            Type type = GetType();
            var fieldInfos = type.GetFields();
            foreach (var fieldInfo in fieldInfos)
            {
                var fieldName = fieldInfo.Name;
                if (!fieldNames.ContainsKey(fieldName))
                {
                    Debug.LogError($"fieldName:{fieldName}不存在");
                    continue;
                }
                int index = fieldNames[fieldName];
                if (fieldInfo.FieldType == typeof(int))
                {
                    data[index] = fieldInfo.GetValue(this).ToString();
                }
                else if (fieldInfo.FieldType == typeof(string))
                {
                    data[index] = fieldInfo.GetValue(this).ToString();
                }
                else if (fieldInfo.FieldType == typeof(float))
                {
                    data[index] = fieldInfo.GetValue(this).ToString();
                }
                else
                {
                    data[index] = string.Empty;
                }
            }
        }
    }
    public interface IConfigBase
    {
        bool IsLoaded { get; }
        ConfigItem GetConfigItem(int id);
        List<int> GetKeys();
        void Reset();
        bool Load(string filePath);
        bool Save();
    }
    public class ConfigBase<T> : IConfigBase where T : ConfigItem, new()
    {
        public bool IsLoaded
        {
            get { return !m_rawData.IsEmpty(); }
        }
        protected string m_filePath;
        protected ConfigRawData m_rawData = new ConfigRawData();
        protected List<int> m_keys = new List<int>();
        protected Dictionary<int, T> m_items = new Dictionary<int, T>();

        public List<int> GetKeys()
        {
            return m_keys;
        }
        
        public ConfigItem GetConfigItem(int id)
        {
            if (m_items.ContainsKey(id))
                return m_items[id];
            if (!m_rawData.Exist(id))
                return null;
            T item = new T();
            item.Parse(m_rawData.FieldNamesDict, m_rawData.GetData(id));
            m_items.Add(id, item);
            return item;
        }
        public T GetItem(int id)
        {
            return GetConfigItem(id) as T;
        }
        public void AddItem(int id, T item)
        {
            if (m_items.ContainsKey(id))
                return;
            m_items.Add(id, item);
            m_keys.Add(id);
        }
        public void ResetData()
        {
            m_rawData.ResetData();
            m_items.Clear();
            m_keys.Clear();
        }

        public void Reset()
        {
            m_rawData.Reset();
            m_items.Clear();
            m_keys.Clear();
        }

        public bool Load(string filePath)
        {
#if UNITY_EDITOR
            if (!File.Exists(filePath))
            {
                Debug.LogError($"{filePath} 不存在！");
                return false;
            }
            m_filePath = filePath;
            var fileName = Path.GetFileName(filePath);
            XSSFWorkbook wk = null;
            try
            {
                FileStream fStream = File.Open(filePath, FileMode.Open, FileAccess.Read);
                wk = new XSSFWorkbook(fStream);
                fStream.Close();
            }
            catch(Exception e)
            {
                Debug.LogError(e.ToString());
            }
            if (wk == null)
                return false;

            ISheet sheet = wk.GetSheetAt(0);
            if (sheet == null)
            {
                Debug.LogError($"{fileName} sheet 不存在");
                return false;
            }
            int rowCount = sheet.LastRowNum;
            if (rowCount < 3)
            {
                Debug.LogError($"{fileName} 小于3行 不符合配置标准");
                return false;
            }
            IRow row = null;
            ICell cell = null;

            //解析字段
            List<string> fieldTypes = new List<string>();
            row = sheet.GetRow(0);
            for (int cellIndex = 0; cellIndex <= row.LastCellNum; ++cellIndex)
            {
                cell = row.GetCell(cellIndex);
                if (cell == null || cell.CellType == CellType.Blank)
                    break;
                fieldTypes.Add(cell.StringCellValue);
            }

            List<string> fieldNames = new List<string>();
            row = sheet.GetRow(2);
            for (int cellIndex = 0; cellIndex <= row.LastCellNum; ++cellIndex)
            {
                cell = row.GetCell(cellIndex);
                if (cell == null || cell.CellType == CellType.Blank)
                    break;
                fieldNames.Add(cell.StringCellValue);
            }
            if (fieldTypes.Count != fieldNames.Count)
            {
                Debug.LogError($"字段类型和字段名称数量不匹配 {fieldTypes.Count}!={fieldNames.Count}");
                return false;
            }
            m_rawData.Init(fileName);
            m_keys.Clear();
            m_rawData.SetFields(fieldTypes.ToArray(), fieldNames.ToArray());

            //解析数据
            for (int rowIndex = 3; rowIndex <= rowCount; ++rowIndex)
            {
                row = sheet.GetRow(rowIndex);
                if (row == null)
                    break;
                //第一个必须是id
                cell = row.GetCell(0);
                if (cell == null)
                    break;
                var idStr = _GetCellData(fieldTypes[0], cell);
                if (string.IsNullOrEmpty(idStr))
                    break;
                int id = int.Parse(idStr);
                if (id == -1)
                {
                    break;
                }
                
                if (m_rawData.Exist(id))
                {
                    Debug.LogError($"重复id {id}");
                    continue;
                }
                List<string> datas = new List<string>();
                for (int cellIndex = 0; cellIndex < fieldNames.Count; ++cellIndex)
                {
                    cell = row.GetCell(cellIndex);
                    datas.Add(_GetCellData(fieldTypes[cellIndex], cell));
                }
                m_rawData.SetData(id, datas.ToArray());
                m_keys.Add(id);
            }
            return true;
#endif
            return false;

        }
        public bool Save()
        {
#if UNITY_EDITOR
            if (string.IsNullOrEmpty(m_filePath))
            {
                return false;
            }
            if (m_keys.Count < 1)
            {
                return false;
            }
            try
            {
                IWorkbook wk = null;
                using (FileStream fStream = File.Open(m_filePath, FileMode.Open, FileAccess.Read))
                {
                    wk = new XSSFWorkbook(fStream);
                    ISheet sheet = wk.GetSheetAt(0);
                    IRow row = null;
                    ICell cell = null;
                    int startRow = 3;

                    int lastRowNum = sheet.LastRowNum;
                    int rowIndex = 0;
                    //写入数据
                    for (int i = 0; i < m_keys.Count; ++i)
                    {
                        var key = m_keys[i];
                        rowIndex = startRow + i;
                        if (rowIndex <= lastRowNum)
                        {
                            row = sheet.GetRow(rowIndex);
                        }
                        else
                        {
                            row = sheet.CreateRow(rowIndex);
                        }
                        string[] data = null;
                        if (m_items.ContainsKey(key))
                        {
                            data = m_rawData.GetData(key);
                            if (data == null)
                            {
                                data = new string[m_rawData.FieldNames.Length];
                                m_rawData.SetData(key, data);
                            }
                            m_items[key].PackData(m_rawData.FieldNamesDict, ref data);
                        }
                        else
                        {
                            data = m_rawData.GetData(key);
                        }

                        for (int index = 0; index < data.Length; ++index)
                        {
                            if (rowIndex <= lastRowNum)
                            {
                                cell = row.GetCell(index);
                            }
                            else
                            {
                                cell = row.CreateCell(index);
                            }
                            var dataType = m_rawData.FieldTypes[index];
                            _SetCellData(dataType, data[index], ref cell);
                        }
                    }
                    //清空数据(多余的行)
                    if (rowIndex < lastRowNum)
                    {
                        for (int i = rowIndex + 1; i <= lastRowNum; ++i)
                        {
                            row = sheet.GetRow(i);
                            if (row == null)
                                continue;
                            sheet.RemoveRow(row);
                        }
                    }
                }
                if (wk == null)
                    return false;
                File.Delete(m_filePath);
                using (FileStream fs = File.Open(m_filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite))
                {
                    wk.Write(fs);
                }
            }
            catch(Exception e)
            {
                Debug.LogError(e.ToString());
                return false;
            }
            return true;
#endif
            return false;
        }


        //解析xmlcell数据
        private string _GetCellData(string dataType, ICell cell)
        {
            if (cell == null)
                return string.Empty;
            switch (cell.CellType)
            {
                case CellType.Blank:
                    return string.Empty;
                case CellType.Numeric:
                    if (dataType == "int")
                        return ((int)cell.NumericCellValue).ToString();
                    return cell.NumericCellValue.ToString();
                case CellType.String:
                case CellType.Formula:
                    if (dataType == "int" || dataType == "float")
                        return cell.StringCellValue;
                    //约定，string类型为0表示空字串
                    if (cell.StringCellValue == "0")
                        return string.Empty;
                    return cell.StringCellValue;
            }
            Debug.LogError($"未处理cell类型 {cell.CellType} row:{cell.Row} col:{cell.ColumnIndex}");
            return string.Empty;
        }
        private void _SetCellData(string dataType, string data, ref ICell cell)
        {
            switch (dataType)
            {
                case "int":
                    cell.SetCellValue(int.Parse(data));
                    break;
                case "float":
                    cell.SetCellValue(float.Parse(data));
                    break;
                case "string":
                    //约定，string类型为0表示空字串
                    if (string.IsNullOrEmpty(data))
                    {
                        cell.SetCellValue("0");
                    }
                    else
                    {
                        cell.SetCellValue(data);
                    }
                    break;
                default:
                    Debug.LogError($"未知类型 {dataType}");
                    break;
            }
        }
    
    }
    
}

