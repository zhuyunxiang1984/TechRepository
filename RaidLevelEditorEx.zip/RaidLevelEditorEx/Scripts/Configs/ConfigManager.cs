﻿using System;
using System.Collections.Generic;
using UnityEngine;


namespace OWG.RaidLevelEditor
{
    public enum EnumConfigName
    {
        RaidChapter = 0,
        RaidLevel,
        Building,
        BuildingBasic,
        BuildingLevel,
        Force,
        Division,
        UnitLevel,
        Unit,
        Item,
        LanguageConfig,
        MapBasicInfo,
        EventTrigger,
        EventAction,
        Count,
    }

    public class ConfigManager
    {
        private static ConfigManager m_instance;
        public static ConfigManager instance
        {
            get
            { 
                if (m_instance == null)
                    m_instance = new ConfigManager();
                return m_instance;
            }
        }
        private Dictionary<EnumConfigName, string> m_dictFileNames = new Dictionary<EnumConfigName, string>()
        {
            { EnumConfigName.RaidChapter, "raidChapter.xlsx"},
            { EnumConfigName.RaidLevel, "raidLevel.xlsx"},

            { EnumConfigName.Building, "building.xlsx"},
            { EnumConfigName.BuildingBasic, "buildingbasic.xlsx"},
            { EnumConfigName.BuildingLevel, "building_level.xlsx"},

            { EnumConfigName.Force, "forces.xlsx"},
            { EnumConfigName.Division, "division.xlsx"},
            { EnumConfigName.UnitLevel, "unit_level.xlsx"},
            { EnumConfigName.Unit, "unit.xlsx"},
            { EnumConfigName.Item, "item.xlsx"},

            { EnumConfigName.LanguageConfig, "language_config.xlsx"},
            { EnumConfigName.MapBasicInfo, "mapBasicInfo.xlsx"},

            { EnumConfigName.EventTrigger, "eventTrigger.xlsx"},
            { EnumConfigName.EventAction, "eventAction.xlsx"},
        };

        private Dictionary<EnumConfigName, Func<IConfigBase>> m_dictConfigFactory = new Dictionary<EnumConfigName, Func<IConfigBase>>()
        {
            { EnumConfigName.RaidChapter, ()=>{ return new ConfigBase<RaidChapterInfo>(); } },
            { EnumConfigName.RaidLevel, ()=>{ return new ConfigBase<RaidLevelInfo>(); } },

            { EnumConfigName.Building, ()=>{ return new ConfigBase<BuildingInfo>(); }},
            { EnumConfigName.BuildingBasic, ()=>{ return new ConfigBase<BuildingBasicInfo>(); }},
            { EnumConfigName.BuildingLevel, ()=>{ return new ConfigBase<BuildingLevelInfo>(); }},

            { EnumConfigName.Force, ()=>{ return new ConfigBase<ForceInfo>(); }},
            { EnumConfigName.Division, ()=>{ return new ConfigBase<DivisionInfo>(); }},
            { EnumConfigName.UnitLevel, ()=>{ return new ConfigBase<UnitLevelInfo>(); }},
            { EnumConfigName.Unit, ()=>{ return new ConfigBase<UnitInfo>(); }},
            { EnumConfigName.Item, ()=>{ return new ConfigBase<ItemInfo>(); }},

            { EnumConfigName.LanguageConfig, ()=>{ return new ConfigBase<LanguageConfigInfo>(); }},
            { EnumConfigName.MapBasicInfo, ()=>{ return new ConfigBase<MapBasicInfoInfo>(); }},

            { EnumConfigName.EventTrigger, ()=>{ return new ConfigBase<EventTriggerInfo>(); }},
            { EnumConfigName.EventAction, ()=>{ return new ConfigBase<EventActionInfo>(); }},
        };

        protected int m_count;
        protected IConfigBase[] m_configs;
        protected bool[] m_dirty;

        public ConfigManager()
        {
            m_count = (int)EnumConfigName.Count;
            m_configs = new IConfigBase[m_count];
            m_dirty = new bool[m_count];
        }

        public bool Load(EnumConfigName configName, string rootPath)
        {
            if (!m_dictFileNames.ContainsKey(configName))
            {
                Debug.LogError($"没有配置filename {configName}");
                return false;
            }
                
            if (!m_dictConfigFactory.ContainsKey(configName))
            {
                Debug.LogError($"没有配置factory {configName}");
                return false;
            }
            var fileName = m_dictFileNames[configName];
            var filePath = $"{Application.dataPath}/{rootPath}/{fileName}";
            int index = (int)configName;
            if (index < 0 || index >= m_count)
                return false;
            var config = m_configs[index];
            if (config == null)
            {
                config = m_dictConfigFactory[configName].Invoke();
                m_configs[index] = config;
            }
            config.Reset();
            return config.Load(filePath);
        }


        public IConfigBase GetConfig(EnumConfigName configName)
        {
            int index = (int)configName;
            if (index < 0 || index >= m_count)
                return null;
            return m_configs[index];
        }

        public List<int> GetKeys(EnumConfigName configName)
        {
            var config = GetConfig(configName);
            if (config == null)
                return null;
            return config.GetKeys();
        }

        public T GetItem<T>(EnumConfigName configName, int id) where T : ConfigItem
        {
            var config = GetConfig(configName);
            if (config == null)
                return null;
            return config.GetConfigItem(id) as T;
        }
    }
}