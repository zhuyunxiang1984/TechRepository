﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 定义结构用于读取配置表
/// </summary>
namespace OWG.RaidLevelEditor
{
    //RaidChapter
    public class RaidChapterInfo : ConfigItem
    {
        public int titleName;
        public string link;
    }
    //RaidLevel
    public class RaidLevelInfo : ConfigItem
    {
        public int levelNum;
        public int levelName;
        public string _ps;
        public string prelevel;
        public string nextlevel;
        public int raidType;
        public int sizeW;
        public int sizeH;
        public string map;
        public string mapBasic;
        public string mapInitRes;
        public string mapEvent;
        public int cameraStartPos;
        public string levelTask;
        public string levelTaskPara1;
        public string levelTaskPara2;
        public string failConditionType;
        public string failConditionPara1;
        public string failConditionPara2;
        public int initMoney;
        public int playerUnitCount;
        public int playerUnitType;
        public string playerUnitForceID;
        public string buff;
        public string fixedTroopID;

        public string playerUnitForcePos;
        public string fixedTroopPos;
        public string unlock;
        public int iconType;
        public string otherTask;
        public string otherTaskPara1;
        public string otherTaskPara2;
        public int quote;
        public int speaker;
        public int recommendedPower;
    }

    //Mapxxx
    public class MapInfo : ConfigItem
    {
        public string resource;
        public int type;
        public int groundType;
        public string elements;
        public int isMoveCity;
    }

    //MapBasicxxx
    public class MapBasicInfo : ConfigItem
    {
        public int buildingID;
        public int pathPoint;
        public int mapBasicInfoID;
        public int unitIndex;
        public int outputIndex;
        public int mapReward;
        public int mapLv;
        public string mapName;
        public int isPlayerSpawner;
        public int lookDir;
    }
    //MapBasicInfo
    public class MapBasicInfoInfo : ConfigItem
    {
        public string defendPoint;
    }
    //Building
    public class BuildingInfo : ConfigItem
    {
        public string resource;
        public float zoomSzie;
    }

    //BuildingBasic
    public class BuildingBasicInfo : ConfigItem
    {
        public string _ps;
        public int initLevel;
    }
    //BuildingLevel
    public class BuildingLevelInfo : ConfigItem
    {
        public int expand;
    }

    //Force
    public class ForceInfo : ConfigItem
    {
        public string _ps1;
        public string division;
    }

    //Division
    public class DivisionInfo : ConfigItem
    {
        public string brigade;
    }

    //UnitLevel
    public class UnitLevelInfo : ConfigItem
    {
        public int unitId;
    }

    //Unit
    public class UnitInfo : ConfigItem
    {
        public string resource;
    }

    //Item
    public class ItemInfo : ConfigItem
    {
        public string _ps;
        public string modelID;
        public string effects;
    }
    //language_config
    public class LanguageConfigInfo : ConfigItem
    {
        public string descCN;
        public string desc;
    }
    //Eventxxx
    public class EventInfo : ConfigItem
    {
        public string _ps;
        public int triggerId;
        public int tileId;
        public string actionId;
        public string actiontileId;
    }
    //eventTrigger
    public class EventTriggerInfo : ConfigItem
    {
        public string _ps;
        public int type;
        public int side;
        public string forceGroup;
        public int playerTroops;
        public string terrainGroup;
        public int unitSelect;
        public int state;
        public int resource;
        public int mathMark;
        public int value;
        public float delayTime;
        public int triggerTimes;
    }
    //eventAction
    public class EventActionInfo : ConfigItem
    {
        public string _ps;
        public int type;
        public int forceGroup;
        public int troopsType;
        public int playerTroops;
        public string terrainGroup;
        public int building;
        public int troopParaType;
        public int num;
        public string phrase;
        public int buff;
        public float timeLast;
        public int side;
        public string showEfects;
    }
}
