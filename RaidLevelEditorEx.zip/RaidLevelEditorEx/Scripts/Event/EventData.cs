using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    [ExecuteInEditMode]
    public class EventData : MonoBehaviour
    {
        [LabelText("����"), TextArea]
        public string _ps;
        [HideLabel]
        public TriggerData TriggerData;

        [LabelText("������Ϊ"), Space(20)]
        public List<ActionData> ActionDatas = new List<ActionData>();

        public void Init(EventInfo mapEventInfo, List<KeyValuePair<int, int>> Actions = null)
        {
            var eventTriggerInfo = ConfigManager.instance.GetItem<EventTriggerInfo>(EnumConfigName.EventTrigger, mapEventInfo.triggerId);
            if (eventTriggerInfo == null)
                return;
            _ps = mapEventInfo._ps;
            TriggerData = new TriggerData();
            TriggerData.MapIndex = mapEventInfo.tileId;
            TriggerData.SetData(eventTriggerInfo);
            if (Actions != null)
            {
                foreach (var pairs in Actions)
                {
                    AddAction(pairs.Key, pairs.Value);
                }
            }
        }

        [SerializeField, HideInInspector]
        protected int m_SizeW, m_SizeH;
        [SerializeField, HideInInspector]
        protected float m_Size, m_HalfSize;
        [SerializeField, HideInInspector]
        protected float m_HalfTotalSizeW, m_HalfTotalSizeH;
        public void SetMapData(int sizeW, int sizeH)
        {
            m_SizeW = sizeW;
            m_SizeH = sizeH;
            m_Size = RaidLevelConst.MapUnitWidth;
            m_HalfSize = m_Size * 0.5f;
            m_HalfTotalSizeW = m_SizeW * m_Size * 0.5f;
            m_HalfTotalSizeH = m_SizeH * m_Size * 0.5f;
        }

        public void AddAction(int actionId, int actionMapIndex)
        {
            var eventActionInfo = ConfigManager.instance.GetItem<EventActionInfo>(EnumConfigName.EventAction, actionId);
            if (eventActionInfo == null)
                return;
            var actionData = new ActionData();
            actionData.MapIndex = actionMapIndex;
            actionData.SetData(eventActionInfo);
            ActionDatas.Add(actionData);
        }

        private void Update()
        {
            if (TriggerData == null)
                return;
            if (TriggerData.MapIndex >= 0)
            {
                gameObject.name = $"Event_�ؿ��¼�_{TriggerData.MapIndex}";
            }
            else
            {
                gameObject.name = $"Event_ȫ���¼�";
            }
            
        }

        protected Dictionary<int, int> _TempDict = new Dictionary<int, int>();
        private void OnDrawGizmosSelected()
        {
            if (TriggerData == null)
                return;
            Handles.BeginGUI();

            if (TriggerData.MapIndex >= 0)
            {
                Gizmos.color = Color.yellow;
                GUI.color = Color.yellow;
                foreach (var actionData in ActionDatas)
                {
                    Gizmos.DrawLine(_GetPos(TriggerData.MapIndex), _GetPos(actionData.MapIndex));
                }
                var pos = _GetPos(TriggerData.MapIndex);
                Gizmos.DrawWireCube(pos, new Vector3(m_Size, 10f, m_Size) * 0.5f);

                var point = HandleUtility.WorldToGUIPoint(pos);
                var rect = new Rect(point.x, point.y, 200, 20);
                GUI.Label(rect, TriggerData.id.ToString());
            }
            Gizmos.color = Color.green;
            GUI.color = Color.green;

            _TempDict.Clear();
            foreach (var actionData in ActionDatas)
            {
                var pos = _GetPos(actionData.MapIndex);
                Gizmos.DrawWireCube(pos, new Vector3(m_Size, 10f, m_Size) * 0.5f);

                if (_TempDict.ContainsKey(actionData.MapIndex))
                {
                    _TempDict[actionData.MapIndex] += 1;
                }
                else
                {
                    _TempDict[actionData.MapIndex] = 1;
                }
                var point = HandleUtility.WorldToGUIPoint(pos);
                var rect = new Rect(point.x, point.y + 10 * _TempDict[actionData.MapIndex], 200, 20);
                GUI.Label(rect, actionData.id.ToString());
            }
            Handles.EndGUI();
        }

        private Vector3 _GetPos(int index)
        {
            if (m_SizeW <= 0)
                return Vector3.zero;
            var x = index % m_SizeW;
            var z = index / m_SizeW;
            return new Vector3(-m_HalfTotalSizeW + m_HalfSize + x * m_Size, 0f, -m_HalfTotalSizeH + m_HalfSize + z * m_Size);
        }
    }
}

#endif