using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public enum EnumActionType
    {
        None = 0,
        GenerateTroop   = 1,//1 刷出部队
        ShowDialog      = 5,//5 副本对话
        TroopMove       = 9,//9 部队移动
        MapChangeOwner  = 14,//14 地块归属转移
        OpenFog         = 18,//18 开启迷雾
        AddEffect       = 19,//19 添加地块效果
        DelEffect       = 20,//20 删除地块效果

        Count,
    }

    [Serializable]
    public class ActionData
    {
        [LabelText("备注"), LabelWidth(50), DisplayAsString]
        public string _ps;
        [HorizontalGroup, LabelText("行为"), LabelWidth(50), OnValueChanged("_OnChangeId")]
        public int id;
        [HorizontalGroup, LabelText("地块"), LabelWidth(50)]
        public int MapIndex;

        [HorizontalGroup, Button("编辑")]
        void OpenEditActionWindow()
        {
            var info = ConfigManager.instance.GetItem<EventActionInfo>(EnumConfigName.EventAction, id);
            if (info == null)
            {
                EditorUtility.DisplayDialog("Error", $"没有找到行为{id}", "OK");
                return;
            }
            EditEventActionPanel.Open(id, (info)=>
            {
                SetData(info);
            });
        }

        public void SetData(EventActionInfo info)
        {
            id = info.id;
            _ps = info._ps;
        }

        protected void _OnChangeId()
        {
            var info = ConfigManager.instance.GetItem<EventActionInfo>(EnumConfigName.EventAction, id);
            if (info != null)
            {
                SetData(info);
            }
        }
    }
    
}

#endif