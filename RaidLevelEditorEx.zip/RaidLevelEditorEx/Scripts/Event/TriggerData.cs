using System;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

#if UNITY_EDITOR
using UnityEditor;

namespace OWG.RaidLevelEditor
{
    public enum EnumTriggerType
    {
        None = 0,
        UnitArrived = 1,//1 单位登陆或经过
        UnitMoniter = 2,//2 单位监视
        //3 资源监视
        TimeMoniter = 4,//4 时间监视
        GameStart   = 5,//5 关卡开始
        //6 单位数监视
        //7 将领施放技能
        Count,
    }

    [Serializable]
    public class TriggerData
    {
        [LabelText("备注"), LabelWidth(50), DisplayAsString]
        public string _ps;
        [HorizontalGroup, LabelText("条件"), LabelWidth(50), OnValueChanged("_OnChangeId")]
        public int id;
        [HorizontalGroup, LabelText("地块"), LabelWidth(50)]
        public int MapIndex = -1;
        [HorizontalGroup, Button("编辑")]
        void OpenEditTriggerWindow()
        {
            var info = ConfigManager.instance.GetItem<EventTriggerInfo>(EnumConfigName.EventTrigger, id);
            if (info == null)
            {
                EditorUtility.DisplayDialog("Error", $"没有找到条件{id}", "OK");
                return;
            }
            EditEventTriggerPanel.Open(id, (info) =>
            {
                SetData(info);
            });
        }

        public void SetData(EventTriggerInfo info)
        {
            id              = info.id;
            _ps             = info._ps;
        }

        protected void _OnChangeId()
        {
            var info = ConfigManager.instance.GetItem<EventTriggerInfo>(EnumConfigName.EventTrigger, id);
            if (info != null)
            {
                SetData(info);
            }
        }
    }
}

#endif