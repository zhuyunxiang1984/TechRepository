﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.UI;

[CustomEditor(typeof(EmojiText), true)]
[CanEditMultipleObjects]
public class EmojiTextInspector : Editor
{

	public override void OnInspectorGUI()
	{
		base.OnInspectorGUI();
		//EmojiText text = target as EmojiText;

	}

}