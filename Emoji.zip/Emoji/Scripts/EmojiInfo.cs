﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EmojiInfo
{
    //文本索引位
	public int index = -1;
    //坐标
	public Vector3 startPos;
    //emoji数据
	public EmojiIndexInfo uvIndexInfo;
}


public class EmojiIndexInfo
{
	public Vector2 offset;
	public float size;

	public static bool isReadEmojiConfig = false;
	public static Dictionary<string, EmojiIndexInfo> emojiIndex = null;

	public static void ReadEmojiIndexConfig()
	{
		TextAsset emojiContent = Resources.Load<TextAsset>("emoji");
		if (emojiContent == null) {
			return;
		}
		emojiIndex = new Dictionary<string, EmojiIndexInfo>();

		string[] lines = emojiContent.text.Split('\n');
		for (int i = 1; i < lines.Length; i++) {
			if (!string.IsNullOrEmpty(lines[i])) {
				string[] strs = lines[i].Split('\t');
				EmojiIndexInfo info = new EmojiIndexInfo();
				info.offset.x = float.Parse(strs[3]);
				info.offset.y = float.Parse(strs[4]);
				info.size = float.Parse(strs[5]);
				emojiIndex.Add(strs[1], info);
			}
		}
		isReadEmojiConfig = true;
	}

	public static EmojiIndexInfo GetIndexInfo(string key)
	{
		if (emojiIndex.ContainsKey(key)) return emojiIndex[key];
		return null;
	}
}