﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using UnityEngine.UI;

//[System.Serializable]
//public class EmojiImage
//{
//    //偏移
//    public Vector2 Offset;
//    //缩放
//    public Vector2 ScalePercent = Vector2.one;

//    /*
//        左下角为原点,水平向右x为正，垂直向下y为正
//        3--2
//        |  |
//        0--1
//    */
//	private static Vector2[] pv = new Vector2[] {
//				new Vector2( 0,  0),
//				new Vector2( 1,  0),
//				new Vector2( 1, -1),
//				new Vector2( 0, -1),
//			};

//	private static Vector2[] uvv = new Vector2[] {
//				new Vector2( 0,  1),
//				new Vector2( 1,  1),
//				new Vector2( 1,  0),
//				new Vector2( 0,  0),
//			};

//	private static Vector2[] sizeScale = new Vector2[] {
//				new Vector2( -1,  1),
//				new Vector2(  1,  1),
//				new Vector2(  1, -1),
//				new Vector2( -1, -1),
//			};

//    //生成emoji的顶点数据
//	public List<UIVertex> GetVertexList(EmojiInfo ei, int w, int h, float scale)
//	{
//		List<UIVertex> vertexList = new List<UIVertex>();
//		for (int i = 0; i < 4; i++) {
//			UIVertex vert = UIVertex.simpleVert;
//			vert.color = Color.white;

//            var position = new Vector3(ei.startPos.x + pv[i].x * w, ei.startPos.y + pv[i].y * h, 0f);

//            //位置偏移
//            position.x += Offset.x;
//            position.y += Offset.y;

//            //大小缩放
//            position.x += sizeScale[i].x * w * ScalePercent.x;
//            position.y += sizeScale[i].y * h * ScalePercent.y;

//			vert.position = position * scale;
//			vert.uv0 = (ei.uvIndexInfo.offset + uvv[i]) * ei.uvIndexInfo.size + Vector2.one;
//			vertexList.Add(vert);
//		}


//		return vertexList;
//	}
//}
