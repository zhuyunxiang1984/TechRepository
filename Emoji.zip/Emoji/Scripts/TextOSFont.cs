﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class TextOSFont : MonoBehaviour
{
    public string DefaultFontName = "";

    protected Text m_text;

    protected static bool m_OSFontInited;
    protected static Dictionary<string, bool> m_dictOSFontFlags = new Dictionary<string, bool>();
    protected static Dictionary<string, Dictionary<int, Font>> m_dictOSFonts = new Dictionary<string, Dictionary<int, Font>>();

    void Awake()
    {
        Init();
    }
    void Start()
    {
        if (!string.IsNullOrEmpty(DefaultFontName))
        {
            SetOSFont(DefaultFontName);
        }
    }

    public void Init()
    {
        if (!m_OSFontInited)
        {
            Debug.Log("====系统拥有字体====");
            var fontNames = Font.GetOSInstalledFontNames();
            foreach (var fontName in fontNames)
            {
                if (m_dictOSFontFlags.ContainsKey(fontName))
                    continue;
                Debug.Log($"系统字体: {fontName}");
                m_dictOSFontFlags.Add(fontName, true);
            }
            m_OSFontInited = true;
        }
        m_text = GetComponent<Text>();
    }

    public void SetOSFont(string fontName)
    {
        Init();
        if (!m_dictOSFontFlags.ContainsKey(fontName))
        {
            Debug.LogError($"系统字体 {fontName} 不存在");
            return;
        }
        Dictionary<int, Font> temp = null;
        if (m_dictOSFonts.ContainsKey(fontName))
        {
            temp = m_dictOSFonts[fontName];
        }
        else
        {
            temp = new Dictionary<int, Font>();
            m_dictOSFonts.Add(fontName, temp);
        }
        int fontSize = m_text.fontSize;
        Font font = null;
        if (temp.ContainsKey(fontSize))
        {
            font = temp[fontSize];
        }
        else
        {
            font = Font.CreateDynamicFontFromOSFont(fontName, fontSize);
            if (font == null)
            {
                Debug.LogError($"创建系统字体失败 fontName:{fontName} fontSize:{fontSize}");
                return;
            }
            temp.Add(fontSize, font);
        }
        m_text.font = font;
    }
}
