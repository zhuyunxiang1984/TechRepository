﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public class EmojiText : Text
{
	public override float preferredWidth => cachedTextGeneratorForLayout.GetPreferredWidth(emojiText, GetGenerationSettings(rectTransform.rect.size)) / pixelsPerUnit;
	public override float preferredHeight => cachedTextGeneratorForLayout.GetPreferredHeight(emojiText, GetGenerationSettings(rectTransform.rect.size)) / pixelsPerUnit;

    [Header("用于Emoji的替换字符，必须是2个相同字符")]
	public string EmojiReplaceStr = "##";

    //
    public int EmojiSizeCount = 7;

    //偏移
    [Header("Emoji偏移")]
    public Vector2 EmojiOffset = Vector2.zero;
    //缩放
    [Header("Emoji缩放")]
    public Vector2 EmojiScalePercent = Vector2.zero;

    //public EmojiImage image = new EmojiImage();

	readonly UIVertex[] m_TempVerts = new UIVertex[4];

    private const string m_EmojiPattern = "<sprite=[0-9]+>";
    public string emojiText
    {
        get
        {
            return Regex.Replace(text, m_EmojiPattern, EmojiReplaceStr);
        }
    }
    protected Dictionary<int, EmojiInfo> m_dictEmojiDatas = new Dictionary<int, EmojiInfo>();

    protected override void OnPopulateMesh(VertexHelper toFill)
	{
		if (font == null)
			return;
        
		if (!EmojiIndexInfo.isReadEmojiConfig) {
            //读取emoji配置
			EmojiIndexInfo.ReadEmojiIndexConfig();
		}
        m_dictEmojiDatas.Clear();

        var emojiTextCache = emojiText;

        if (supportRichText)
        {
			List<EmojiInfo> tempEmojiInfo = ParserEmoji(text, m_EmojiPattern);

            UpdateEmptyChar(tempEmojiInfo, emojiTextCache, @"[ \r\n\t]+");

			for (int i = 0; i < tempEmojiInfo.Count; ++i) {
				EmojiInfo ei = tempEmojiInfo[i];
                m_dictEmojiDatas.Add(ei.index, ei);
			}
		}

		// We don't care if we the font Texture changes while we are doing our Update.
		// The end result of cachedTextGenerator will be valid for this instance.
		// Otherwise we can get issues like Case 619238.
		m_DisableFontTextureRebuiltCallback = true;

		Vector2 extents = rectTransform.rect.size;

		var settings = GetGenerationSettings(extents);
		cachedTextGenerator.Populate(emojiTextCache, settings);

		Rect inputRect = rectTransform.rect;

		// get the text alignment anchor point for the text in local space
		Vector2 textAnchorPivot = GetTextAnchorPivot(alignment);
		Vector2 refPoint = Vector2.zero;
		refPoint.x = Mathf.Lerp(inputRect.xMin, inputRect.xMax, textAnchorPivot.x);
		refPoint.y = Mathf.Lerp(inputRect.yMin, inputRect.yMax, textAnchorPivot.y);
        //Debug.Log($"textAnchorPivot:{textAnchorPivot} refPoint:{refPoint}");
		// Determine fraction of pixel to offset text mesh.
		Vector2 roundingOffset = PixelAdjustPoint(refPoint) - refPoint;
        //Debug.Log($"pixeladjust:{PixelAdjustPoint(refPoint)} refPoint:{refPoint}");
        // Apply the offset to the vertices
        IList<UIVertex> verts = cachedTextGenerator.verts;
		float unitsPerPixel = 1 / pixelsPerUnit;
		//Last 4 verts are always a new line...
		int vertCount = verts.Count;
        float imageW = -1, imageH = -1, imageScale = 1 / pixelsPerUnit;

        toFill.Clear();
        if (roundingOffset == Vector2.zero) {
			for (int i = 0; i < vertCount;)
            {
				int index = i / 4;
				if (m_dictEmojiDatas.ContainsKey(index)) {
					EmojiInfo ei = m_dictEmojiDatas[index];
					if (ei == null) continue;

                    if (imageW < 0) imageW = verts[i + 1].position.x - verts[i].position.x;
                    if (imageH < 0) imageH = verts[i + 1].position.y - verts[i + 2].position.y;

                    var imageSize = Mathf.Max(imageW, imageH);
                    ei.startPos = verts[i].position + new Vector3(imageW - imageSize * 0.5f, 0, 0);

                    //这里做一次x位置修正，保证在前后字母的中间
                    var temp1 = i - 3;
                    var temp2 = i + 8;
                    if (temp1 >= 0 && temp1 < vertCount &&
                        temp2 >= 0 && temp2 < vertCount)
                    {
                        var pos1 = verts[temp1].position;
                        var pos2 = verts[temp2].position;
                        //说明处于同一行
                        if (pos2.x > pos1.x)
                        {
                            ei.startPos.x = Mathf.Lerp(verts[temp1].position.x, verts[temp2].position.x, 0.5f);
                            ei.startPos.x -= imageSize * 0.5f;
                            ei.startPos.y = verts[i].position.y;
                        }
                    }

					List<UIVertex> list = GetVertexList(ei, (int)imageSize, (int)imageSize, imageScale);
					if (list.Count > 0) {

						toFill.AddUIVertexQuad(list.ToArray());
					}

					//Debug.LogErrorFormat("Size = [{0}, {1}], fontSize = [{2}]", fCharWidth, fCharHeight, fontSize);
					//Debug.LogErrorFormat("startPos = [{0}]", ei.startPos.ToString());
					//for (int j = 0; j < 8; ++j) {
					//	if (j % 4 >= 2) continue;
					//	Debug.LogErrorFormat("Old => Vertex[{0}], [index:{1}] [position:{2}]", i + j, index, verts[i + j].position.ToString());
					//}
					//for (int j = 0; j < list.Count; ++j) {
					//	if (j % 4 >= 2) continue;
					//	Debug.LogErrorFormat("New => Vertex[{0}], [index:{1}] [position:{2}]", i + j, index, list[j].position.ToString());
					//}

					i += 8;
				} else
                {
					int tempVertsIndex = i & 3;
					m_TempVerts[tempVertsIndex] = verts[i];
					m_TempVerts[tempVertsIndex].position *= unitsPerPixel;
					m_TempVerts[tempVertsIndex].uv1 = Vector3.zero;
					if (tempVertsIndex == 3)
						toFill.AddUIVertexQuad(m_TempVerts);
                    //Debug.LogErrorFormat("Old => Vertex[{0}], [index:{1}] [position:{2}]", i, index, verts[i].position.ToString());
                    ++i;
                }
			}
		} else {
			for (int i = 0; i < vertCount; ++i) {
				int tempVertsIndex = i & 3;
				m_TempVerts[tempVertsIndex] = verts[i];
				m_TempVerts[tempVertsIndex].position *= unitsPerPixel;
				m_TempVerts[tempVertsIndex].position.x += roundingOffset.x;
				m_TempVerts[tempVertsIndex].position.y += roundingOffset.y;
				m_TempVerts[tempVertsIndex].uv1 = Vector3.zero;
				if (tempVertsIndex == 3)
					toFill.AddUIVertexQuad(m_TempVerts);
			}
		}
        m_DisableFontTextureRebuiltCallback = false;

    }

    //解析原始本中的表情列表
    public List<EmojiInfo> ParserEmoji(string text, string pattern)
	{
		int nParcedCount = 0;
		//[1] [123] 替换成#的下标偏移量			
		int nOffset = 0;
		MatchCollection matches = Regex.Matches(text, pattern);
        
		List<EmojiInfo> tempEmojiInfo = new List<EmojiInfo>();

		for (int i = 0; i < matches.Count; i++) {
            var temp = Regex.Matches(matches[i].Value, @"[0-9]+");
            EmojiIndexInfo info = EmojiIndexInfo.GetIndexInfo($"[{temp[0].Value}]");
            if (info == null) continue;

			EmojiInfo ei = new EmojiInfo();
			tempEmojiInfo.Add(ei);
			ei.uvIndexInfo = info;
			//Debug.LogErrorFormat("emoji[{0}] at {1}, nOffset[{2}], nParcedCount[{3}]", matches[i].Value, matches[i].Index, nOffset, nParcedCount);
			ei.index = matches[i].Index - nOffset + nParcedCount;
			nOffset += matches[i].Length - 1;
			nParcedCount++;
		}
		return tempEmojiInfo;
	}

    //修正emoji在文本中的索引
	public void UpdateEmptyChar(List<EmojiInfo> list, string text, string pattern)
	{
		MatchCollection matches = Regex.Matches(text, pattern);
		int backCount = 0;
		int j = 0;
		for (int i = 0; i < list.Count; i++) {
			EmojiInfo ei = list[i];

			for (; j < matches.Count; ++j) {
				Match match = matches[j];
				if (match.Index > ei.index) break;

				backCount += match.Value.Length;
			}

			ei.index -= backCount;
		}
	}

    #region 生成emoji顶点数据

    private static Vector2[] pv = new Vector2[] {
                new Vector2( 0,  0),
                new Vector2( 1,  0),
                new Vector2( 1, -1),
                new Vector2( 0, -1),
            };

    private static Vector2[] uvv = new Vector2[] {
                new Vector2( 0,  1),
                new Vector2( 1,  1),
                new Vector2( 1,  0),
                new Vector2( 0,  0),
            };

    private static Vector2[] sizeScale = new Vector2[] {
                new Vector2( -1,  1),
                new Vector2(  1,  1),
                new Vector2(  1, -1),
                new Vector2( -1, -1),
            };

    //生成emoji的顶点数据
    /*
        左下角为原点,水平向右x为正，垂直向下y为正
        3--2
        |  |
        0--1
    */
    private List<UIVertex> GetVertexList(EmojiInfo ei, int w, int h, float scale)
    {
        List<UIVertex> vertexList = new List<UIVertex>();
        for (int i = 0; i < 4; i++)
        {
            UIVertex vert = UIVertex.simpleVert;
            vert.color = Color.white;

            var position = new Vector3(ei.startPos.x + pv[i].x * w, ei.startPos.y + pv[i].y * h, 0f);

            //位置偏移
            position.x += EmojiOffset.x;
            position.y += EmojiOffset.y;

            //大小缩放
            position.x += sizeScale[i].x * w * EmojiScalePercent.x;
            position.y += sizeScale[i].y * h * EmojiScalePercent.y;

            vert.position = position * scale;
            vert.uv0 = new Vector2(-1,-1);
            vert.uv1.x = (ei.uvIndexInfo.offset.x + uvv[i].x) / EmojiSizeCount;
            vert.uv1.y = (EmojiSizeCount - 1 - ei.uvIndexInfo.offset.y + uvv[i].y) / EmojiSizeCount;
            vertexList.Add(vert);
        }


        return vertexList;
    }

    #endregion

#if UNITY_EDITOR
    protected override void OnValidate()
	{
		base.OnValidate();

		//if (image == null) image = new EmojiImage();
		//image.width = (int)(image.widthPercent * fontSize * 0.5f);
		//image.height = (int)(image.heightPercent * fontSize * 0.5f);
	}
#endif
}
