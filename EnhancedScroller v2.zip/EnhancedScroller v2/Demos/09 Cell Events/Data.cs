﻿namespace EnhancedScrollerDemos.CellEvents
{
    public class Data
    {
        public int hour;
    }
}