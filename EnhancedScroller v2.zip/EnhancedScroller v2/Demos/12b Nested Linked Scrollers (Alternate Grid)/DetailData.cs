﻿namespace EnhancedScrollerDemos.NestedLinkedScrollers
{
    /// <summary>
    /// Super simple data class to hold information for each detail cell.
    /// </summary>
    public class DetailData
    {
        public string someText;
    }
}