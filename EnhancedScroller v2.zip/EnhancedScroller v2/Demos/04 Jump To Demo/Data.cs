﻿using UnityEngine;
using System.Collections;

namespace EnhancedScrollerDemos.JumpToDemo
{
    public class Data
    {
        public string cellText;
    }
}