﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

#if UNITY_EDITOR
using UnityEditor;
#endif

[ExecuteInEditMode]
public class XUIGray : MonoBehaviour
{
    public Material GrayMat;
    public bool AlwaysCollect = false;
    //包含所有Image组件
    public GameObject[] Objs;
    //指定Image组件
    public Image[] Images;
    //指定Text组件
    public Text[] Texts;

    private void Awake()
    {
#if UNITY_EDITOR
        GrayMat = AssetDatabase.LoadAssetAtPath<Material>("Assets/ThirdPackage/XGrayImage/XUIGrayMaterial.mat");
#endif
        _CollectImages();
    }

    public void Gray()
    {
        _RestoreImage();
        _GrayImage();

        _RestoreText();
        _GrayText();
    }
    public void Restore()
    {
        _RestoreImage();
        _RestoreText();
    }

    protected List<Image>    _RecordImgs = new List<Image>();
    protected List<Material> _RecordMats = new List<Material>();
    protected void _CollectImages()
    {
        _RecordImgs.Clear();
        if (Objs != null)
        {
            foreach (var obj in Objs)
            {
                if (obj == null)
                    continue;
                var imgs = obj.GetComponentsInChildren<Image>();
                if (imgs != null)
                {
                    _RecordImgs.AddRange(imgs);
                }
            }
        }
        if (Images != null)
        {
            foreach (var img in Images)
            {
                if (img == null)
                    continue;
                _RecordImgs.Add(img);
            }
        }
    }
    protected void _GrayImage()
    {
        if (GrayMat == null)
            return;
        if (_RecordImgs.Count < 1 || AlwaysCollect)
        {
            _CollectImages();
        }
        if (_RecordImgs.Count < 1)
            return;
        foreach (var img in _RecordImgs)
        {
            _RecordMats.Add(img.material);
            img.material = GrayMat;
        }
    }
    protected void _RestoreImage()
    {
        if (GrayMat == null)
            return;
        if (_RecordMats.Count < 1)
            return;
        for (int i = 0; i < _RecordMats.Count; ++i)
        {
            _RecordImgs[i].material = _RecordMats[i];
        }
        _RecordMats.Clear();
    }

    protected List<Color> m_RecordCols = new List<Color>();
    protected void _GrayText()
    {
        if (Texts == null)
            return;
        foreach (var text in Texts)
        {
            m_RecordCols.Add(text.color);
            text.color = Color.gray;
        }
    }
    protected void _RestoreText()
    {
        if (Texts == null)
            return;
        if (m_RecordCols.Count < 1)
            return;
        for (int i = 0; i < Texts.Length; ++i)
        {
            Texts[i].color = m_RecordCols[i];
        }
        m_RecordCols.Clear();
    }
}
