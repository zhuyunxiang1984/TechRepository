﻿using System.Text;
using UnityEngine;

namespace XGameKit.Core
{
    public class XDebugLogger
    {
        public bool mute;//是否禁止
        public string prefix;//前缀
        public string color; //颜色 rrggbbaa

        public StringBuilder StrBuilder { get; protected set; } = new StringBuilder(128);
        public void Log()
        {
            if (mute) return;
            _AppendPrefix();
            _AppendColorx();
            Debug.Log(StrBuilder.ToString());
        }
        public void LogError()
        {
            //需要被人看到，所以这里不启动mute判断
            //if (mute) return;
            _AppendPrefix();
            _AppendColorx();
            Debug.LogError(StrBuilder.ToString());
        }
        public void LogWarning()
        {
            if (mute) return;
            _AppendPrefix();
            _AppendColorx();
            Debug.LogWarning(StrBuilder.ToString());
        }
        
        
        //添加前缀
        private void _AppendPrefix()
        {
            if (string.IsNullOrEmpty(prefix))
                return;
            StrBuilder.Insert(0, "[" + prefix + "]");
        }
        //添加颜色
        private void _AppendColorx()
        {
            //换行符会打乱染色，所以每一个换行都要染色
            StrBuilder.Insert(0, "<color=#" + color + ">");
            StrBuilder.Replace("\n", "</color>\n<color=#" + color + ">");
            StrBuilder.Append("</color>");
        }
    }
}