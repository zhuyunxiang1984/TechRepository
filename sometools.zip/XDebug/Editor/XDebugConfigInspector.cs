﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditorInternal;

namespace XGameKit.Core
{
    [CustomEditor(typeof(XDebugConfig), true)]
    public class XLoggerConfigInspector : Editor
    {

        protected ReorderableList m_ReorderableList;

        void OnEnable()
        {
            m_ReorderableList = new ReorderableList(serializedObject, serializedObject.FindProperty("listLoggerInfo"), true, true, true, true);
            m_ReorderableList.drawHeaderCallback = (rect) =>
            {
                GUI.Label(rect, "Logger配置列表");
            };
            m_ReorderableList.drawElementCallback = (rect, index, selected, focuse) =>
            {
                SerializedProperty item = m_ReorderableList.serializedProperty.GetArrayElementAtIndex(index);
                rect.height -= 4;
                rect.y += 2;
                EditorGUI.PropertyField(rect, item, new GUIContent("Index " + index));
            };
            m_ReorderableList.onRemoveCallback = (list) =>
            {
                if (EditorUtility.DisplayDialog("Warnning", "Do you want to remove this element?", "Remove", "Cancel"))
                {
                    ReorderableList.defaultBehaviours.DoRemoveButton(list);
                }
            };
            m_ReorderableList.onAddCallback = (list) =>
            {
                if (list.serializedProperty != null)
                {
                    list.serializedProperty.arraySize++;
                    list.index = list.serializedProperty.arraySize - 1;

                    SerializedProperty itemData = list.serializedProperty.GetArrayElementAtIndex(list.index);
                    itemData.FindPropertyRelative("active").boolValue = false;
                    itemData.FindPropertyRelative("name").stringValue = string.Empty;
                    itemData.FindPropertyRelative("color").colorValue = Color.white;
                }
                else
                {
                    ReorderableList.defaultBehaviours.DoAddButton(list);
                }
            };
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            m_ReorderableList.DoLayoutList();
            serializedObject.ApplyModifiedProperties();

            if (GUILayout.Button("保存设定"))
            {
                AssetDatabase.SaveAssets();
            }
            if (GUILayout.Button("应用设定"))
            {
                (target as XDebugConfig).Apply();
            }
        }

    }
}