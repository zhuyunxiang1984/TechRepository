﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace XGameKit.Core
{
    [CustomPropertyDrawer(typeof(XDebugConfig.LoggerInfo))]
    public class XLoggerConfigDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            using (new EditorGUI.PropertyScope(position, label, property))
            {
                EditorGUIUtility.labelWidth = 60;

                SerializedProperty value1 = property.FindPropertyRelative("active");
                SerializedProperty value2 = property.FindPropertyRelative("name");
                SerializedProperty value3 = property.FindPropertyRelative("color");

                var rect1 = new Rect(position) { width = 20 };
                var rect2 = new Rect(position) { width = (position.width - rect1.width) * 0.5f, x = rect1.x + rect1.width };
                var rect3 = new Rect(position) { width = (position.width - rect1.width) * 0.5f, x = rect2.x + rect2.width };

                EditorGUI.PropertyField(rect1, value1, new GUIContent());
                EditorGUI.PropertyField(rect2, value2, new GUIContent());
                EditorGUI.PropertyField(rect3, value3, new GUIContent());
            }            
        }
    }
}

