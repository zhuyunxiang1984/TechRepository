using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[ExecuteInEditMode]
public class XUIMosica : MonoBehaviour
{
    [Range(0, 1)]
    public float Intensity = 1f;
    [Range(1,50)]
    public float Mosica = 50f;
    
    protected Material _MatCache;
    protected Material _Mat
    {
        get
        {
            if (_MatCache == null)
            {
                var img = GetComponent<Image>();
                if (img != null)
                {
                    _MatCache = img.material;
                }
            }
            if (_MatCache == null)
            {
                var img = GetComponent<RawImage>();
                if (img != null)
                {
                    _MatCache = img.material;
                }
            }
            return _MatCache;
        }
    }
    protected float _Mosica;
    protected float _Intensity;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (_CheckChanged())
        {
            _SyncMaterial();
        }
    }

    bool _CheckChanged()
    {
        bool changed = false;
        if (_Mosica != Mosica)
        {
            _Mosica = Mosica;
            changed = true;
        }
        if (_Intensity != Intensity)
        {
            _Intensity = Intensity;
            changed = true;
        }
        return changed;
    }

    void _SyncMaterial()
    {
        if (_Mat == null)
            return;
        _Mat.SetFloat("_Intensity", _Intensity);
        _Mat.SetFloat("_Mosica", _Mosica);
    }
}
